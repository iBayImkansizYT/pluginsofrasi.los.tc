<?php
  if ($readAdmin["permission"] != 1) {
    go('/yonetim-paneli/hata/001');
  }
  require_once(__ROOT__.'/apps/dashboard/private/packages/class/extraresources/extraresources.php');
  $extraResourcesJS = new ExtraResources('js');
  if (get("target") == 'header' && get("action") == 'update') {
    $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/theme.header.js');
  }
  $theme = $db->query("SELECT * FROM Theme ORDER BY id DESC LIMIT 1");
  $readTheme = $theme->fetch();
?>
<?php if (get("target") == 'header'): ?>
  <?php if (get("action") == 'update'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Header</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Tema</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Header</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3">
          <div class="card">
            <div class="card-header">
              Header Elaman Ekle/Düzenle
            </div>
            <div class="card-body">
              <form id="formNestable" class="form-horizontal">
                <div class="form-group">
                  <label for="selectPageList">Sayfa Türü:</label>
                  <select id="selectPageTypeList" class="form-control" name="pageTypeList" data-toggle="select" data-minimum-results-for-search="-1">
                    <option value="custom">Özel Sayfa</option>
                    <option value="home">Ana Sayfa</option>
                    <option value="store">Mağaza</option>
                    <option value="credit">Kredi</option>
                    <option value="credit-charge">Kredi Yükle</option>
                    <option value="leaderboards">Sıralama</option>
                    <option value="support">Destek</option>
                    <option value="download">İndir</option>
                  </select>
                  <input type="hidden" name="pagetype" value="custom">
                </div>
                <div class="form-group">
                  <label for="inputTitle">Başlık:</label>
                  <div class="input-group">
                    <input type="text" id="inputTitle" class="form-control" name="title" placeholder="Örn: Özel Sayfa">
                    <div class="input-group-append">
                      <button type="button" class="btn btn-success" data-toggle="iconpicker"></button>
                    </div>
                  </div>
                  <input type="hidden" id="inputIcon" name="icon">
                </div>
                <div class="form-group">
                  <label for="inputURL">Bağlantı (URL):</label>
                  <input type="text" class="form-control" id="inputURL" name="url" placeholder="Örn: /ozel-sayfa">
                </div>
                <div class="form-group">
                  <label for="selectTab">Sekme:</label>
                  <select id="selectTabStatus" class="form-control" name="tabstatus" data-toggle="select" data-minimum-results-for-search="-1">
                    <option value="0">Aynı Sekme</option>
                    <option value="1">Yeni Sekme</option>
                  </select>
                </div>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="button" class="btn btn-rounded btn-danger" data-action="cancel" style="display: none;">İptal</button>
                    <button type="button" class="btn btn-rounded btn-success" data-action="update" style="display: none;">Güncelle</button>
                    <button type="button" class="btn btn-rounded btn-success" data-action="insert" style="display: inline-block;">Ekle</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-9">
          <?php
            require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
            $csrf = new CSRF('csrf-sessions', 'csrf-token');
            if (isset($_POST["updateHeader"])) {
              if (!$csrf->validate('updateHeader')) {
                echo alertError("Sistemsel bir sorun oluştu!");
              }
              else if (post("json") == null) {
                echo alertError("Lütfen boş alan bırakmayınız!");
              }
              else {
                $updateTheme = $db->prepare("UPDATE Theme SET header = ? WHERE id = ?");
                $updateTheme->execute(array($_POST["json"], $readTheme["id"]));
                echo alertSuccess("Değişiklikler başarıyla kaydedildi!");
              }
            }
          ?>
          <div class="card">
            <div class="card-header">
              Header Elamanları
            </div>
            <div class="card-body">
              <form action="" method="post">
                <div class="form-group">
                  <div class="dd" data-toggle="nestable"></div>
                  <input type="hidden" name="json" value='<?php echo htmlentities($readTheme["header"], ENT_QUOTES, 'UTF-8'); ?>'>
                </div>
                <?php echo $csrf->input('updateHeader'); ?>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="submit" class="btn btn-rounded btn-success" name="updateHeader">Değişiklikleri Kaydet</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php else: ?>
  <?php go('/404'); ?>
<?php endif; ?>
