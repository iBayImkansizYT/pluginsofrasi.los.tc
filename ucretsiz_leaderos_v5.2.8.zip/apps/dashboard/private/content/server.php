<?php
  if ($readAdmin["permission"] != 1) {
    go('/yonetim-paneli/hata/001');
  }
  require_once(__ROOT__.'/apps/dashboard/private/packages/class/extraresources/extraresources.php');
  $extraResourcesJS = new ExtraResources('js');
  $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/loader.js');
  if (get("target") == 'server') {
    if (get("action") == 'insert' || get("action") == 'update') {
      $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/server.check.js');
    }
  }
?>
<?php if (get("target") == 'server'): ?>
  <?php if (get("action") == 'getAll'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Sunucular</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Sunucular</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php $servers = $db->query("SELECT * FROM Servers ORDER BY id DESC"); ?>
          <?php if ($servers->rowCount() > 0): ?>
            <div class="card" data-toggle="lists" data-lists-values='["serverID", "servername", "serverIP", "serverConsoleID", "serverConsolePort"]'>
              <div class="card-header">
                <div class="row align-items-center">
                  <div class="col">
                    <div class="row align-items-center">
                      <div class="col-auto pr-0">
                        <span class="fe fe-search text-muted"></span>
                      </div>
                      <div class="col">
                        <input type="search" class="form-control form-control-flush search" name="search" placeholder="Arama Yap">
                      </div>
                    </div>
                  </div>
                  <div class="col-auto">
                    <a class="btn btn-sm btn-white" href="/yonetim-paneli/sunucu/ekle">Sunucu Ekle</a>
                  </div>
                </div>
              </div>
              <div id="loader" class="card-body p-0 is-loading">
                <div id="spinner">
                  <div class="spinner-border" role="status">
                    <span class="sr-only">-/-</span>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-sm table-nowrap card-table">
                    <thead>
                      <tr>
                        <th class="text-center" style="width: 40px;">
                          <a href="#" class="text-muted sort" data-sort="serverID">
                            #ID
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="servername">
                            Sunucu Adı
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="serverIP">
                            Sunucu IP:Port
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="serverConsoleID">
                            Konsol Tipi
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="serverConsolePort">
                            Konsol Port
                          </a>
                        </th>
                        <th class="text-right">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody class="list">
                      <?php foreach ($servers as $readServers): ?>
                        <tr>
                          <td class="serverID text-center" style="width: 40px;">
                            <a href="/yonetim-paneli/sunucu/duzenle/<?php echo $readServers["id"]; ?>">
                              #<?php echo $readServers["id"]; ?>
                            </a>
                          </td>
                          <td class="servername">
                            <a href="/yonetim-paneli/sunucu/duzenle/<?php echo $readServers["id"]; ?>">
                              <?php echo $readServers["name"]; ?>
                            </a>
                          </td>
                          <td class="serverIP">
                            <?php echo $readServers["ip"].":".$readServers["port"]; ?>
                          </td>
                          <td class="serverConsoleID">
                            <?php echo ($readServers["consoleID"] == 1 ? 'Websend' : (($readServers["consoleID"] == 2) ? 'RCON' : (($readServers["consoleID"] == 3) ? 'Websender' : 'Hata!'))); ?>
                          </td>
                          <td class="serverConsolePort">
                            <?php echo $readServers["consolePort"]; ?>
                          </td>
                          <td class="text-right">
                            <a class="btn btn-sm btn-rounded-circle btn-success" href="/yonetim-paneli/sunucu/duzenle/<?php echo $readServers["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Düzenle">
                              <i class="fe fe-edit-2"></i>
                            </a>
                            <a class="btn btn-sm btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/sunucu/sil/<?php echo $readServers["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                              <i class="fe fe-trash-2"></i>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'insert'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Sunucu Ekle</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/sunucu">Sunucular</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Sunucu Ekle</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
            $csrf = new CSRF('csrf-sessions', 'csrf-token');
            if (isset($_POST["insertServers"])) {
              if (!$csrf->validate('insertServers')) {
                echo alertError("Sistemsel bir sorun oluştu!");
              }
              else if (post("name") == null || post("ip") == null || post("port") == null || post("consoleID") == null || post("consolePort") == null || post("consolePassword") == null) {
                echo alertError("Lütfen boş alan bırakmayınız!");
              }
              else if ($_FILES["image"]["size"] == null) {
                echo alertError("Lütfen bir resim seçiniz!");
              }
              else {
                require_once(__ROOT__."/apps/dashboard/private/packages/class/upload/upload.php");
                $upload = new \Verot\Upload\Upload($_FILES["image"], "tr_TR");
                $imageID = md5(uniqid(rand(0, 9999)));
                if ($upload->uploaded) {
                  $upload->allowed = array("image/*");
                  $upload->file_new_name_body = $imageID;
                  $upload->image_resize = true;
                  $upload->image_ratio_crop = true;
                  $upload->image_x = 640;
                  $upload->image_y = 360;
                  $upload->process(__ROOT__."/apps/main/public/assets/img/servers/");
                  if ($upload->processed) {
                    $insertServers = $db->prepare("INSERT INTO Servers (name, slug, ip, port, consoleID, consolePort, consolePassword, imageID, imageType) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $insertServers->execute(array(post("name"), convertURL(post("name")), post("ip"), post("port"), post("consoleID"), post("consolePort"), post("consolePassword"), $imageID, $upload->file_dst_name_ext));
                    echo alertSuccess("Sunucu başarıyla eklendi!");
                  }
                  else {
                    echo alertError("Resim yüklenirken bir hata oluştu: ".$upload->error);
                  }
                }
              }
            }
          ?>
          <div class="card">
            <div class="card-body">
              <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group row">
                  <label for="inputName" class="col-sm-2 col-form-label">Sunucu Adı:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputName" class="form-control" name="name" placeholder="Sunucu adını giriniz.">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputIP" class="col-sm-2 col-form-label">Sunucu IP:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputIP" class="form-control" name="ip" placeholder="Sunucu IP adresini giriniz.">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputPort" class="col-sm-2 col-form-label">Sunucu Port:</label>
                  <div class="col-sm-10">
                    <input type="number" id="inputPort" class="form-control" name="port" placeholder="Sunucu portunu giriniz.">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectConsoleID" class="col-sm-2 col-form-label">Konsol Türü:</label>
                  <div class="col-sm-10">
                    <select id="selectConsoleID" class="form-control" name="consoleID" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="1">Websend</option>
                      <option value="2">RCON</option>
                      <option value="3">Websender</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputConsolePort" class="col-sm-2 col-form-label">Konsol Port:</label>
                  <div class="col-sm-10">
                    <input type="number" id="inputConsolePort" class="form-control" name="consolePort" placeholder="Konsol portunu giriniz.">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputConsolePassword" class="col-sm-2 col-form-label">Konsol Şifre:</label>
                  <div class="col-sm-10">
                    <input type="password" id="inputConsolePassword" class="form-control" name="consolePassword" placeholder="Konsol şifresini giriniz.">
                    <div id="checkConnect" class="mt-3">
                      <div class="spinner-grow spinner-grow-sm mr-2" role="status" style="display: none;">
                        <span class="sr-only">-/-</span>
                      </div>
                      <a href="javascript:void(0);">Konsol Bağlantısını Kontrol Et</a>
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="fileImage" class="col-sm-2 col-form-label">Resim:</label>
                  <div class="col-sm-10">
                    <div data-toggle="dropimage" class="dropimage">
                      <div class="di-thumbnail">
                        <img src="" alt="Ön İzleme">
                      </div>
                      <div class="di-select">
                        <label for="fileImage">Bir Resim Seçiniz</label>
                        <input type="file" id="fileImage" name="image" accept="image/*">
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo $csrf->input('insertServers'); ?>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="submit" class="btn btn-rounded btn-success" name="insertServers">Ekle</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'update' && get("id")): ?>
    <?php
      $server = $db->prepare("SELECT * FROM Servers WHERE id = ?");
      $server->execute(array(get("id")));
      $readServer = $server->fetch();
    ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Sunucu Düzenle</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/sunucu">Sunucular</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/sunucu">Sunucu Düzenle</a></li>
                      <li class="breadcrumb-item active" aria-current="page"><?php echo ($server->rowCount() > 0) ? $readServer["name"] : "Bulunamadı!"; ?></li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php if ($server->rowCount() > 0): ?>
            <?php
              require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
              $csrf = new CSRF('csrf-sessions', 'csrf-token');
              if (isset($_POST["updateServers"])) {
                if (!$csrf->validate('updateServers')) {
                  echo alertError("Sistemsel bir sorun oluştu!");
                }
                else if (post("name") == null || post("ip") == null || post("port") == null || post("consoleID") == null || post("consolePort") == null || post("consolePassword") == null) {
                  echo alertError("Lütfen boş alan bırakmayınız!");
                }
                else {
                  if ($_FILES["image"]["size"] != null) {
                    require_once(__ROOT__."/apps/dashboard/private/packages/class/upload/upload.php");
                    $upload = new \Verot\Upload\Upload($_FILES["image"], "tr_TR");
                    $imageID = $readServer["imageID"];
                    if ($upload->uploaded) {
                      $upload->allowed = array("image/*");
                      $upload->file_overwrite = true;
                      $upload->file_new_name_body = $imageID;
                      $upload->image_resize = true;
                      $upload->image_ratio_crop = true;
                      $upload->image_x = 640;
                      $upload->image_y = 360;
                      $upload->process(__ROOT__."/apps/main/public/assets/img/servers/");
                      if ($upload->processed) {
                        $updateServers = $db->prepare("UPDATE Servers SET imageType = ? WHERE id = ?");
                        $updateServers->execute(array($upload->file_dst_name_ext, $readServer["id"]));
                      }
                      else {
                        echo alertError("Resim yüklenirken bir hata oluştu: ".$upload->error);
                      }
                    }
                  }

                  $updateServers = $db->prepare("UPDATE Servers SET name = ?, slug = ?, ip = ?, port = ?, consoleID = ?, consolePort = ?, consolePassword = ? WHERE id = ?");
                  $updateServers->execute(array(post("name"), convertURL(post("name")), post("ip"), post("port"), post("consoleID"), post("consolePort"), post("consolePassword"), get("id")));
                  echo alertSuccess("Değişiklikler başarıyla kaydedildi!");
                }
              }
            ?>
            <div class="card">
              <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data">
                  <div class="form-group row">
                    <label for="inputName" class="col-sm-2 col-form-label">Sunucu Adı:</label>
                    <div class="col-sm-10">
                      <input type="text" id="inputName" class="form-control" name="name" placeholder="Sunucu adını giriniz." value="<?php echo $readServer["name"]; ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputIP" class="col-sm-2 col-form-label">Sunucu IP:</label>
                    <div class="col-sm-10">
                      <input type="text" id="inputIP" class="form-control" name="ip" placeholder="Sunucu IP adresini giriniz." value="<?php echo $readServer["ip"]; ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPort" class="col-sm-2 col-form-label">Sunucu Port:</label>
                    <div class="col-sm-10">
                      <input type="number" id="inputPort" class="form-control" name="port" placeholder="Sunucu portunu giriniz." value="<?php echo $readServer["port"]; ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectConsoleID" class="col-sm-2 col-form-label">Konsol Türü:</label>
                    <div class="col-sm-10">
                      <select id="selectConsoleID" class="form-control" name="consoleID" data-toggle="select" data-minimum-results-for-search="-1">
                        <option value="1" <?php echo ($readServer["consoleID"] == 1) ? 'selected="selected"' : null; ?>>Websend</option>
                        <option value="2" <?php echo ($readServer["consoleID"] == 2) ? 'selected="selected"' : null; ?>>RCON</option>
                        <option value="3" <?php echo ($readServer["consoleID"] == 3) ? 'selected="selected"' : null; ?>>Websender</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputConsolePort" class="col-sm-2 col-form-label">Konsol Port:</label>
                    <div class="col-sm-10">
                      <input type="number" id="inputConsolePort" class="form-control" name="consolePort" placeholder="Konsol portunu giriniz." value="<?php echo $readServer["consolePort"]; ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputConsolePassword" class="col-sm-2 col-form-label">Konsol Şifre:</label>
                    <div class="col-sm-10">
                      <input type="password" id="inputConsolePassword" class="form-control" name="consolePassword" placeholder="Konsol şifresini giriniz." value="<?php echo $readServer["consolePassword"]; ?>">
                      <div id="checkConnect" class="mt-3">
                        <div class="spinner-grow spinner-grow-sm mr-2" role="status" style="display: none;">
                          <span class="sr-only">-/-</span>
                        </div>
                        <a href="javascript:void(0);">Konsol Bağlantısını Kontrol Et</a>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="fileImage" class="col-sm-2 col-form-label">Resim:</label>
                    <div class="col-sm-10">
                      <div data-toggle="dropimage" class="dropimage active">
                        <div class="di-thumbnail">
                          <img src="/apps/main/public/assets/img/servers/<?php echo $readServer["imageID"].'.'.$readServer["imageType"]; ?>" alt="Ön İzleme">
                        </div>
                        <div class="di-select">
                          <label for="fileImage">Bir Resim Seçiniz</label>
                          <input type="file" id="fileImage" name="image" accept="image/*">
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php echo $csrf->input('updateServers'); ?>
                  <div class="clearfix">
                    <div class="float-right">
                      <a class="btn btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/sunucu/sil/<?php echo $readServer["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                        <i class="fe fe-trash-2"></i>
                      </a>
                      <a class="btn btn-rounded-circle btn-primary" href="/yonetim-paneli/sunucu/ozet/<?php echo $readServer["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Konsol & Özet">
                        <i class="fe fe-activity"></i>
                      </a>
                      <button type="submit" class="btn btn-rounded btn-success" name="updateServers">Değişiklikleri Kaydet</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'delete' && get("id")): ?>
    <?php
      $deleteServer = $db->prepare("DELETE FROM Servers WHERE id = ?");
      $deleteServer->execute(array(get("id")));
      go("/yonetim-paneli/sunucu");
    ?>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php else: ?>
  <?php go('/404'); ?>
<?php endif; ?>
