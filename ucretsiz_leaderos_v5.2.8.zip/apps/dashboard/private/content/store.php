<?php
  if ($readAdmin["permission"] != 1) {
    go('/yonetim-paneli/hata/001');
  }
  require_once(__ROOT__.'/apps/dashboard/private/packages/class/extraresources/extraresources.php');
  $extraResourcesJS = new ExtraResources('js');
  $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/loader.js');
  if (get("target") == 'product' && (get("action") == 'insert' || get("action") == 'update')) {
    $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/store.product.js');
  }
  if (get("target") == 'category' && (get("action") == 'insert' || get("action") == 'update')) {
    $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/store.category.js');
  }
  if (get("target") == 'credit' && get("action") == 'send') {
    $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/payment.js');
  }
?>
<?php if (get("target") == 'product'): ?>
  <?php if (get("action") == 'getAll'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Ürünler</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Ürün</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            $products = $db->prepare("SELECT P.*, PC.name as categoryName, S.name as serverName FROM Products P LEFT JOIN ProductCategories PC ON P.categoryID = PC.id OR P.categoryID = ? INNER JOIN Servers S ON P.serverID = S.id GROUP BY P.id ORDER BY P.id DESC");
            $products->execute(array(0));
          ?>
          <?php if ($products->rowCount() > 0): ?>
            <div class="card" data-toggle="lists" data-lists-values='["productID", "productName", "productCategoryName", "productServerName", "productPrice"]'>
              <div class="card-header">
                <div class="row align-items-center">
                  <div class="col">
                    <div class="row align-items-center">
                      <div class="col-auto pr-0">
                        <span class="fe fe-search text-muted"></span>
                      </div>
                      <div class="col">
                        <input type="search" class="form-control form-control-flush search" name="search" placeholder="Arama Yap">
                      </div>
                    </div>
                  </div>
                  <div class="col-auto">
                    <a class="btn btn-sm btn-white" href="/yonetim-paneli/magaza/urun/ekle">Ürün Ekle</a>
                  </div>
                </div>
              </div>
              <div id="loader" class="card-body p-0 is-loading">
                <div id="spinner">
                  <div class="spinner-border" role="status">
                    <span class="sr-only">-/-</span>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-sm table-nowrap card-table">
                    <thead>
                      <tr>
                        <th class="text-center" style="width: 40px;">
                          <a href="#" class="text-muted sort" data-sort="productID">
                            #ID
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="productName">
                            Ürün Adı
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="productCategoryName">
                            Kategori Adı
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="productServerName">
                            Sunucu Adı
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="productPrice">
                            Fiyat
                          </a>
                        </th>
                        <th class="text-right">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody class="list">
                      <?php foreach ($products as $readProducts): ?>
                        <tr>
                          <td class="productID text-center" style="width: 40px;">
                            <a href="/yonetim-paneli/magaza/urun/duzenle/<?php echo $readProducts["id"]; ?>">
                              #<?php echo $readProducts["id"]; ?>
                            </a>
                          </td>
                          <td class="productName">
                            <a href="/yonetim-paneli/magaza/urun/duzenle/<?php echo $readProducts["id"]; ?>">
                              <?php echo $readProducts["name"]; ?>
                            </a>
                          </td>
                          <td class="productCategoryName">
                            <?php echo (($readProducts["categoryID"] == 0) ? 'Kategorisiz' : $readProducts["categoryName"]); ?>
                          </td>
                          <td class="productServerName">
                            <?php echo $readProducts["serverName"]; ?>
                          </td>
                          <td class="productPrice">
                            <?php echo ($readProducts["discountedPrice"] > 0) ? $readProducts["discountedPrice"] : $readProducts["price"]; ?> kredi
                          </td>
                          <td class="text-right">
                            <a class="btn btn-sm btn-rounded-circle btn-success" href="/yonetim-paneli/magaza/urun/duzenle/<?php echo $readProducts["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Düzenle">
                              <i class="fe fe-edit-2"></i>
                            </a>
                            <a class="btn btn-sm btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/magaza/urun/sil/<?php echo $readProducts["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                              <i class="fe fe-trash-2"></i>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'insert'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Ürün Ekle</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Ürün</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Ürün Ekle</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
            $csrf = new CSRF('csrf-sessions', 'csrf-token');
            if (isset($_POST["insertProducts"])) {
              if (post("durationStatus") == 0) {
                $_POST["duration"] = 0;
              }
              if (post("durationStatus") == -1) {
                $_POST["duration"] = -1;
              }
              if (post("discountStatus") == 0) {
                $_POST["discountedPrice"] = 0;
              }
              if (post("discountDurationStatus") == 0 || post("discountStatus") == 0) {
                $_POST["discountDuration"] = '1000-01-01 00:00:00';
              }
              else {
                $_POST["discountDuration"] = date("Y-m-d H:i:s", strtotime($_POST["discountDuration"]));
              }
              if (!$csrf->validate('insertProducts')) {
                echo alertError("Sistemsel bir sorun oluştu!");
              }
              else if (post("name") == null || post("categoryID") == null || post("serverID") == null || post("details") == null || !count(array_filter($_POST["commands"])) || post("price") == null || post("discountStatus") == null || post("discountedPrice") == null || post("discountDurationStatus") == null || post("discountDuration") == null || post("durationStatus") == null || post("duration") == null) {
                echo alertError("Lütfen boş alan bırakmayınız!");
              }
              else if ($_FILES["image"]["size"] == null) {
                echo alertError("Lütfen bir resim seçiniz!");
              }
              else {
                require_once(__ROOT__."/apps/dashboard/private/packages/class/upload/upload.php");
                $upload = new \Verot\Upload\Upload($_FILES["image"], "tr_TR");
                $imageID = md5(uniqid(rand(0, 9999)));
                if ($upload->uploaded) {
                  $upload->allowed = array("image/*");
                  $upload->file_new_name_body = $imageID;
                  $upload->image_resize = true;
                  $upload->image_ratio_crop = true;
                  $upload->image_x = 360;
                  $upload->image_y = 360;
                  $upload->process(__ROOT__."/apps/main/public/assets/img/store/products/");
                  if ($upload->processed) {
                    $insertProducts = $db->prepare("INSERT INTO Products (name, imageID, imageType, categoryID, serverID, details, price, discountedPrice, discountExpiryDate, duration, creationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $insertProducts->execute(array(post("name"), $imageID, $upload->file_dst_name_ext, post("categoryID"), post("serverID"), filteredContent($_POST["details"]), post("price"), post("discountedPrice"), post("discountDuration"), post("duration"), date("Y-m-d H:i:s")));
                    $productsLastInsertID = $db->lastInsertId();
                    if (count(array_filter($_POST["commands"]))) {
                      $insertProductCommands = $db->prepare("INSERT INTO ProductCommands (productID, command) VALUES (?, ?)");
                      foreach ($_POST["commands"] as $command) {
                        $command = ltrim(strip_tags($command), '/');
                        $insertProductCommands->execute(array($productsLastInsertID, $command));
                      }
                    }
                    echo alertSuccess("Ürün başarıyla eklendi!");
                  }
                  else {
                    echo alertError("Resim yüklenirken bir hata oluştu: ".$upload->error);
                  }
                }
              }
            }
          ?>
          <div class="card">
            <div class="card-body">
              <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group row">
                  <label for="inputname" class="col-sm-2 col-form-label">Ürün Adı:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputname" class="form-control" name="name" placeholder="Ürün adını yazınız.">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectServerID" class="col-sm-2 col-form-label">Sunucu:</label>
                  <div class="col-sm-10">
                    <?php $servers = $db->query("SELECT * FROM Servers"); ?>
                    <select id="selectServerID" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="serverID" <?php echo ($servers->rowCount() == 0) ? "disabled" : null; ?>>
                      <?php if ($servers->rowCount() > 0): ?>
                        <?php foreach ($servers as $readServers): ?>
                          <option value="<?php echo $readServers["id"]; ?>"><?php echo $readServers["name"]; ?></option>
                        <?php endforeach; ?>
                      <?php else: ?>
                        <option>Sunucu bulunamadı!</option>
                      <?php endif; ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectCategoryID" class="col-sm-2 col-form-label">Kategori:</label>
                  <div class="col-sm-10">
                    <div id="c-loading" style="display: none; margin-top: 7px">Yükleniyor...</div>
                    <div id="product-categories">
                      <?php
                        $firstServer = $db->query("SELECT * FROM Servers ORDER BY id ASC LIMIT 1");
                        $readFirstServer = $firstServer->fetch();

                        $productCategories = $db->prepare("SELECT * FROM ProductCategories WHERE serverID = ?");
                        $productCategories->execute(array($readFirstServer["id"]));
                      ?>
                      <select id="selectCategoryID" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="categoryID">
                        <option value="0">Kategorisiz</option>
                        <?php if ($productCategories->rowCount() > 0): ?>
                          <?php foreach ($productCategories as $readProductCategories): ?>
                            <option value="<?php echo $readProductCategories["id"]; ?>"><?php echo $readProductCategories["name"]; ?></option>
                          <?php endforeach; ?>
                        <?php endif; ?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputPrice" class="col-sm-2 col-form-label">Fiyat:</label>
                  <div class="col-sm-10">
                    <div class="input-group input-group-merge">
                      <input type="number" id="inputPrice" class="form-control form-control-prepended" name="price" placeholder="Ürün fiyatını yazınız.">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <span class="fa fa-try"></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectDiscountStatus" class="col-sm-2 col-form-label">İndirim:</label>
                  <div class="col-sm-10">
                    <select id="selectDiscountStatus" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="discountStatus">
                      <option value="0">Yok</option>
                      <option value="1">Var</option>
                    </select>
                  </div>
                </div>
                <div id="discountBlock" style="display: none;">
                  <div class="form-group row">
                    <label for="inputDiscountedPrice" class="col-sm-2 col-form-label">İndirimli Fiyat:</label>
                    <div class="col-sm-10">
                      <div class="input-group input-group-merge">
                        <input type="number" id="inputDiscountedPrice" class="form-control form-control-prepended" name="discountedPrice" placeholder="Ürünün indirimli fiyatını yazınız.">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <span class="fa fa-try"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectDiscountDurationStatus" class="col-sm-2 col-form-label">İndirim Süresi:</label>
                    <div class="col-sm-10">
                      <select id="selectDiscountDurationStatus" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="discountDurationStatus">
                        <option value="0">Süresiz</option>
                        <option value="1">Süreli</option>
                      </select>
                    </div>
                  </div>
                  <div id="discountDurationBlock" style="display: none;">
                    <div class="form-group row">
                      <div class="col-sm-10 offset-sm-2">
                        <div class="input-group input-group-merge">
                          <input type="text" id="inputDiscountDuration" class="form-control form-control-prepended" name="discountDuration" placeholder="Ürüne uygulanacak indirimin son kullanım tarihini seçiniz." data-toggle="flatpickr" data-expirydate="true">
                          <div class="input-group-prepend">
                            <div class="input-group-text">
                              <span class="fe fe-clock"></span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectDurationStatus" class="col-sm-2 col-form-label">Ürün Süresi:</label>
                  <div class="col-sm-10">
                    <select id="selectDurationStatus" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="durationStatus">
                      <option value="0">Süresiz</option>
                      <option value="1">Süreli</option>
                      <option value="-1">Tek Kullanımlık</option>
                    </select>
                  </div>
                </div>
                <div id="durationBlock" style="display: none;">
                  <div class="form-group row">
                    <div class="col-sm-10 offset-sm-2">
                      <div class="input-group input-group-merge">
                        <input type="number" id="inputDuration" class="form-control form-control-prepended" name="duration" placeholder="Ürünün kullanım süresi (Gün).">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <span class="fe fe-clock"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="textareaDetails" class="col-sm-2 col-form-label">Detaylar:</label>
                  <div class="col-sm-10">
                    <textarea id="textareaDetails" class="form-control" data-toggle="textEditor" name="details" placeholder="Ürünün detaylarını/özelliklerini yazınız."></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputTable" class="col-sm-2 col-form-label">Komutlar:</label>
                  <div class="col-sm-10">
                    <div class="table-responsive">
                      <table id="tableitems" class="table table-sm table-hover table-nowrap array-table">
                        <thead>
                          <tr>
                            <th>Komut</th>
                            <th class="text-center pt-0 pb-0 align-middle">
                              <button type="button" class="btn btn-sm btn-rounded-circle btn-success addTableItem">
                                <i class="fe fe-plus"></i>
                              </button>
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>
                              <div class="input-group input-group-merge">
                                <input type="text" class="form-control form-control-prepended" name="commands[]" placeholder="Ürün satın alındığında konsole gönderilecek komudu yazınız.">
                                <div class="input-group-prepend">
                                  <div class="input-group-text">
                                    <span class="fe fe-terminal"></span>
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td class="text-center align-middle">
                              <button type="button" class="btn btn-sm btn-rounded-circle btn-danger deleteTableItem">
                                <i class="fe fe-trash-2"></i>
                              </button>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <small class="form-text text-muted pb-2"><strong>Kullanıcı Adı:</strong> %username%</small>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="fileImage" class="col-sm-2 col-form-label">Resim:</label>
                  <div class="col-sm-10">
                    <div data-toggle="dropimage" class="dropimage">
                      <div class="di-thumbnail">
                        <img src="" alt="Ön İzleme">
                      </div>
                      <div class="di-select">
                        <label for="fileImage">Bir Resim Seçiniz</label>
                        <input type="file" id="fileImage" name="image" accept="image/*">
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo $csrf->input('insertProducts'); ?>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="submit" class="btn btn-rounded btn-success" name="insertProducts">Ekle</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'update' && get("id")): ?>
    <?php
      $product = $db->prepare("SELECT * FROM Products WHERE id = ?");
      $product->execute(array(get("id")));
      $readProduct = $product->fetch();
    ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Ürün Düzenle</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Ürün</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Ürün Düzenle</a></li>
                      <li class="breadcrumb-item active" aria-current="page"><?php echo ($product->rowCount() > 0) ? $readProduct["name"] : "Bulunamadı!"; ?></li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php if ($product->rowCount() > 0): ?>
            <?php
              require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
              $csrf = new CSRF('csrf-sessions', 'csrf-token');
              if (isset($_POST["updateProducts"])) {
                if (post("durationStatus") == 0) {
                  $_POST["duration"] = 0;
                }
                if (post("durationStatus") == -1) {
                  $_POST["duration"] = -1;
                }
                if (post("discountStatus") == 0) {
                  $_POST["discountedPrice"] = 0;
                }
                if (post("discountDurationStatus") == 0 || post("discountStatus") == 0) {
                  $_POST["discountDuration"] = '1000-01-01 00:00:00';
                }
                else {
                  $_POST["discountDuration"] = date("Y-m-d H:i:s", strtotime($_POST["discountDuration"]));
                }
                if (!$csrf->validate('updateProducts')) {
                  echo alertError("Sistemsel bir sorun oluştu!");
                }
                else if (post("name") == null || post("categoryID") == null || post("serverID") == null || post("details") == null || !count(array_filter($_POST["commands"])) || post("price") == null || post("discountStatus") == null || post("discountedPrice") == null || post("discountDurationStatus") == null || post("discountDuration") == null || post("durationStatus") == null || post("duration") == null) {
                  echo alertError("Lütfen boş alan bırakmayınız!");
                }
                else {
                  if ($_FILES["image"]["size"] != null) {
                    require_once(__ROOT__."/apps/dashboard/private/packages/class/upload/upload.php");
                    $upload = new \Verot\Upload\Upload($_FILES["image"], "tr_TR");
                    $imageID = $readProduct["imageID"];
                    if ($upload->uploaded) {
                      $upload->allowed = array("image/*");
                      $upload->file_overwrite = true;
                      $upload->file_new_name_body = $imageID;
                      $upload->image_resize = true;
                      $upload->image_ratio_crop = true;
                      $upload->image_x = 360;
                      $upload->image_y = 360;
                      $upload->process(__ROOT__."/apps/main/public/assets/img/store/products/");
                      if ($upload->processed) {
                        $updateProducts = $db->prepare("UPDATE Products SET imageType = ? WHERE id = ?");
                        $updateProducts->execute(array($upload->file_dst_name_ext, get("id")));
                      }
                      else {
                        echo alertError("Resim yüklenirken bir hata oluştu: ".$upload->error);
                      }
                    }
                  }
                  $updateProducts = $db->prepare("UPDATE Products SET name = ?, categoryID = ?, serverID = ?, details = ?, price = ?, discountedPrice = ?, discountExpiryDate = ?, duration = ? WHERE id = ?");
                  $updateProducts->execute(array(post("name"), post("categoryID"), post("serverID"), filteredContent($_POST["details"]), post("price"), post("discountedPrice"),  post("discountDuration"), post("duration"), get("id")));
                  if (count(array_filter($_POST["commands"]))) {
                    $deleteProductCommands = $db->prepare("DELETE FROM ProductCommands WHERE productID = ?");
                    $deleteProductCommands->execute(array($readProduct["id"]));
                    $insertProductCommands = $db->prepare("INSERT INTO ProductCommands (productID, command) VALUES (?, ?)");
                    foreach ($_POST["commands"] as $command) {
                      $command = ltrim(strip_tags($command), '/');
                      $insertProductCommands->execute(array($readProduct["id"], $command));
                    }
                  }
                  echo alertSuccess("Değişiklikler başarıyla kaydedildi!");
                }
              }
            ?>
            <div class="card">
              <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data">
                  <div class="form-group row">
                    <label for="inputname" class="col-sm-2 col-form-label">Ürün Adı:</label>
                    <div class="col-sm-10">
                      <input type="text" id="inputname" class="form-control" name="name" placeholder="Ürün adını yazınız." value="<?php echo $readProduct["name"]; ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectServerID" class="col-sm-2 col-form-label">Sunucu:</label>
                    <div class="col-sm-10">
                      <?php $servers = $db->query("SELECT * FROM Servers"); ?>
                      <select id="selectServerID" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="serverID" <?php echo ($servers->rowCount() == 0) ? "disabled" : null; ?>>
                        <?php if ($servers->rowCount() > 0): ?>
                          <?php foreach ($servers as $readServers): ?>
                            <option value="<?php echo $readServers["id"]; ?>" <?php echo (($readProduct["serverID"] == $readServers["id"]) ? 'selected="selected"' : null); ?>><?php echo $readServers["name"]; ?></option>
                          <?php endforeach; ?>
                        <?php else: ?>
                          <option>Sunucu bulunamadı!</option>
                        <?php endif; ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectCategoryID" class="col-sm-2 col-form-label">Kategori:</label>
                    <div class="col-sm-10">
                      <div id="c-loading" style="display: none; margin-top: 7px">Yükleniyor...</div>
                      <div id="product-categories">
                        <?php
                          $productCategories = $db->prepare("SELECT * FROM ProductCategories WHERE serverID = ?");
                          $productCategories->execute(array($readProduct["serverID"]));
                        ?>
                        <select id="selectCategoryID" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="categoryID">
                          <option value="0">Kategorisiz</option>
                          <?php if ($productCategories->rowCount() > 0): ?>
                            <?php foreach ($productCategories as $readProductCategories): ?>
                              <option value="<?php echo $readProductCategories["id"]; ?>" <?php echo (($readProduct["categoryID"] == $readProductCategories["id"]) ? 'selected="selected"' : null); ?>><?php echo $readProductCategories["name"]; ?></option>
                            <?php endforeach; ?>
                          <?php endif; ?>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPrice" class="col-sm-2 col-form-label">Fiyat:</label>
                    <div class="col-sm-10">
                      <div class="input-group input-group-merge">
                        <input type="number" id="inputPrice" class="form-control form-control-prepended" name="price" placeholder="Ürün fiyatını yazınız." value="<?php echo $readProduct["price"]; ?>">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <span class="fa fa-try"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectDiscountStatus" class="col-sm-2 col-form-label">İndirim:</label>
                    <div class="col-sm-10">
                      <select id="selectDiscountStatus" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="discountStatus">
                        <option value="0" <?php echo ($readProduct["discountedPrice"] == 0) ? 'selected="selected"' : null; ?>>Yok</option>
                        <option value="1" <?php echo ($readProduct["discountedPrice"] != 0) ? 'selected="selected"' : null; ?>>Var</option>
                      </select>
                    </div>
                  </div>
                  <div id="discountBlock" style="<?php echo ($readProduct["discountedPrice"] == 0) ? "display: none;" : "display: block;"; ?>">
                    <div class="form-group row">
                      <label for="inputDiscountedPrice" class="col-sm-2 col-form-label">İndirimli Fiyat:</label>
                      <div class="col-sm-10">
                        <div class="input-group input-group-merge">
                          <input type="number" id="inputDiscountedPrice" class="form-control form-control-prepended" name="discountedPrice" placeholder="Ürünün indirimli fiyatını yazınız." value="<?php echo ($readProduct["discountedPrice"] != 0) ? $readProduct["discountedPrice"] : null; ?>">
                          <div class="input-group-prepend">
                            <div class="input-group-text">
                              <span class="fa fa-try"></span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="selectDiscountDurationStatus" class="col-sm-2 col-form-label">İndirim Süresi:</label>
                      <div class="col-sm-10">
                        <select id="selectDiscountDurationStatus" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="discountDurationStatus">
                          <option value="0" <?php echo ($readProduct["discountExpiryDate"] == '1000-01-01 00:00:00') ? 'selected="selected"' : null; ?>>Süresiz</option>
                          <option value="1" <?php echo ($readProduct["discountExpiryDate"] != '1000-01-01 00:00:00') ? 'selected="selected"' : null; ?>>Süreli</option>
                        </select>
                      </div>
                    </div>
                    <div id="discountDurationBlock" style="<?php echo ($readProduct["discountExpiryDate"] == '1000-01-01 00:00:00') ? "display: none;" : "display: block;"; ?>">
                      <div class="form-group row">
                        <div class="col-sm-10 offset-sm-2">
                          <div class="input-group input-group-merge">
                            <input type="text" id="inputDiscountDuration" class="form-control form-control-prepended" name="discountDuration" placeholder="Ürüne uygulanacak indirimin son kullanım tarihini seçiniz." data-toggle="flatpickr" data-expirydate="true" value="<?php echo ($readProduct["discountExpiryDate"] != '1000-01-01 00:00:00') ? $readProduct["discountExpiryDate"] : null; ?>">
                            <div class="input-group-prepend">
                              <div class="input-group-text">
                                <span class="fe fe-clock"></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectDurationStatus" class="col-sm-2 col-form-label">Ürün Süresi:</label>
                    <div class="col-sm-10">
                      <select id="selectDurationStatus" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="durationStatus">
                        <option value="0" <?php echo ($readProduct["duration"] == 0) ? 'selected="selected"' : null; ?>>Süresiz</option>
                        <option value="1" <?php echo ($readProduct["duration"] != 0 && $readProduct["duration"] != -1) ? 'selected="selected"' : null; ?>>Süreli</option>
                        <option value="-1" <?php echo ($readProduct["duration"] == -1) ? 'selected="selected"' : null; ?>>Tek Kullanımlık</option>
                      </select>
                    </div>
                  </div>
                  <div id="durationBlock" style="<?php echo ($readProduct["duration"] == 0 || $readProduct["duration"] == -1) ? "display: none;" : "display: block;"; ?>">
                    <div class="form-group row">
                      <div class="col-sm-10 offset-sm-2">
                        <div class="input-group input-group-merge">
                          <input type="number" id="inputDuration" class="form-control form-control-prepended" name="duration" placeholder="Ürünün kullanım süresi (Gün)." value="<?php echo ($readProduct["duration"] != 0) ? $readProduct["duration"] : null; ?>">
                          <div class="input-group-prepend">
                            <div class="input-group-text">
                              <span class="fe fe-clock"></span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="textareaDetails" class="col-sm-2 col-form-label">Detaylar:</label>
                    <div class="col-sm-10">
                      <textarea id="textareaDetails" class="form-control" data-toggle="textEditor" name="details" placeholder="Ürünün detaylarını/özelliklerini yazınız."><?php echo $readProduct["details"]; ?></textarea>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputTable" class="col-sm-2 col-form-label">Komutlar:</label>
                    <div class="col-sm-10">
                      <div class="table-responsive">
                        <table id="tableitems" class="table table-sm table-hover table-nowrap array-table">
                          <thead>
                            <tr>
                              <th>Komut</th>
                              <th class="text-center pt-0 pb-0 align-middle">
                                <button type="button" class="btn btn-sm btn-rounded-circle btn-success addTableItem">
                                  <i class="fe fe-plus"></i>
                                </button>
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                              $productCommands = $db->prepare("SELECT * FROM ProductCommands WHERE productID = ?");
                              $productCommands->execute(array($readProduct["id"]));
                            ?>
                            <?php foreach ($productCommands as $productCommand): ?>
                              <tr>
                                <td>
                                  <div class="input-group input-group-merge">
                                    <input type="text" class="form-control form-control-prepended" name="commands[]" placeholder="Ürün satın alındığında konsole gönderilecek komudu yazınız." value="<?php echo $productCommand["command"]; ?>">
                                    <div class="input-group-prepend">
                                      <div class="input-group-text">
                                        <span class="fe fe-terminal"></span>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td class="text-center align-middle">
                                  <button type="button" class="btn btn-sm btn-rounded-circle btn-danger deleteTableItem">
                                    <i class="fe fe-trash-2"></i>
                                  </button>
                                </td>
                              </tr>
                            <?php endforeach; ?>
                          </tbody>
                        </table>
                      </div>
                      <small class="form-text text-muted pb-2"><strong>Kullanıcı Adı:</strong> %username%</small>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="fileImage" class="col-sm-2 col-form-label">Resim:</label>
                    <div class="col-sm-10">
                      <div data-toggle="dropimage" class="dropimage active">
                        <div class="di-thumbnail">
                          <img src="/apps/main/public/assets/img/store/products/<?php echo $readProduct["imageID"].'.'.$readProduct["imageType"]; ?>" alt="Ön İzleme">
                        </div>
                        <div class="di-select">
                          <label for="fileImage">Bir Resim Seçiniz</label>
                          <input type="file" id="fileImage" name="image" accept="image/*">
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php echo $csrf->input('updateProducts'); ?>
                  <div class="clearfix">
                    <div class="float-right">
                      <a class="btn btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/magaza/urun/sil/<?php echo $readProduct["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                        <i class="fe fe-trash-2"></i>
                      </a>
                      <button type="submit" class="btn btn-rounded btn-success" name="updateProducts">Değişiklikleri Kaydet</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'delete' && get("id")): ?>
    <?php
      $deleteProduct = $db->prepare("DELETE FROM Products WHERE id = ?");
      $deleteProduct->execute(array(get("id")));
      go("/yonetim-paneli/magaza/urun");
    ?>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php elseif (get("target") == 'category'): ?>
  <?php if (get("action") == 'getAll'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Kategoriler</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Kategori</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php $productCategories = $db->query("SELECT PC.*, S.name as serverName, S.slug as serverSlug FROM ProductCategories PC INNER JOIN Servers S ON PC.serverID = S.id ORDER BY PC.id DESC"); ?>
          <?php if ($productCategories->rowCount() > 0): ?>
            <div class="card" data-toggle="lists" data-lists-values='["productCategoryID", "productCategoryName", "productServerName", "productParentCategoryName"]'>
              <div class="card-header">
                <div class="row align-items-center">
                  <div class="col">
                    <div class="row align-items-center">
                      <div class="col-auto pr-0">
                        <span class="fe fe-search text-muted"></span>
                      </div>
                      <div class="col">
                        <input type="search" class="form-control form-control-flush search" name="search" placeholder="Arama Yap">
                      </div>
                    </div>
                  </div>
                  <div class="col-auto">
                    <a class="btn btn-sm btn-white" href="/yonetim-paneli/magaza/kategori/ekle">Kategori Ekle</a>
                  </div>
                </div>
              </div>
              <div id="loader" class="card-body p-0 is-loading">
                <div id="spinner">
                  <div class="spinner-border" role="status">
                    <span class="sr-only">-/-</span>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-sm table-nowrap card-table">
                    <thead>
                      <tr>
                        <th class="text-center" style="width: 40px;">
                          <a href="#" class="text-muted sort" data-sort="productCategoryID">
                            #ID
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="productCategoryName">
                            Kategori Adı
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="productServerName">
                            Sunucu
                          </a>
                        </th>
                        <th>
                          <a href="#" class="text-muted sort" data-sort="productParentCategoryName">
                            Üst Kategori
                          </a>
                        </th>
                        <th class="text-right">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody class="list">
                      <?php foreach ($productCategories as $readProductCategories): ?>
                        <tr>
                          <td class="productCategoryID text-center" style="width: 40px;">
                            <a href="/yonetim-paneli/magaza/kategori/duzenle/<?php echo $readProductCategories["id"]; ?>">
                              #<?php echo $readProductCategories["id"]; ?>
                            </a>
                          </td>
                          <td class="productCategoryName">
                            <a href="/yonetim-paneli/magaza/kategori/duzenle/<?php echo $readProductCategories["id"]; ?>">
                              <?php echo $readProductCategories["name"]; ?>
                            </a>
                          </td>
                          <td class="productServerName">
                            <?php echo $readProductCategories["serverName"]; ?>
                          </td>
                          <td class="productParentCategoryName">
                            <?php
                              $parentCategory = $db->prepare("SELECT name FROM ProductCategories WHERE id = ?");
                              $parentCategory->execute(array($readProductCategories["parentID"]));
                              $readParentCategory = $parentCategory->fetch();
                            ?>
                            <?php if ($parentCategory->rowCount() > 0): ?>
                              <?php echo $readParentCategory["name"]; ?>
                            <?php else: ?>
                              -
                            <?php endif; ?>
                          </td>
                          <td class="text-right">
                            <a class="btn btn-sm btn-rounded-circle btn-success" href="/yonetim-paneli/magaza/kategori/duzenle/<?php echo $readProductCategories["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Düzenle">
                              <i class="fe fe-edit-2"></i>
                            </a>
                            <a class="btn btn-sm btn-rounded-circle btn-primary" href="/magaza/<?php echo $readProductCategories["serverSlug"]; ?>/<?php echo $readProductCategories["slug"]; ?>" rel="external" data-toggle="tooltip" data-placement="top" title="Görüntüle">
                              <i class="fe fe-eye"></i>
                            </a>
                            <a class="btn btn-sm btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/magaza/kategori/sil/<?php echo $readProductCategories["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                              <i class="fe fe-trash-2"></i>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'insert'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Kategori Ekle</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/kategori">Kategori</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Kategori Ekle</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
            $csrf = new CSRF('csrf-sessions', 'csrf-token');
            if (isset($_POST["insertProductCategories"])) {
              if (!$csrf->validate('insertProductCategories')) {
                echo alertError("Sistemsel bir sorun oluştu!");
              }
              else if (post("name") == null || post("serverID") == null || post("parentID") == null) {
                echo alertError("Lütfen boş alan bırakmayınız!");
              }
              else if ($_FILES["image"]["size"] == null) {
                echo alertError("Lütfen bir resim seçiniz!");
              }
              else {
                require_once(__ROOT__."/apps/dashboard/private/packages/class/upload/upload.php");
                $upload = new \Verot\Upload\Upload($_FILES["image"], "tr_TR");
                $imageID = md5(uniqid(rand(0, 9999)));
                if ($upload->uploaded) {
                  $upload->allowed = array("image/*");
                  $upload->file_new_name_body = $imageID;
                  $upload->image_resize = true;
                  $upload->image_ratio_crop = true;
                  $upload->image_x = 360;
                  $upload->image_y = 360;
                  $upload->process(__ROOT__."/apps/main/public/assets/img/store/categories/");
                  if ($upload->processed) {
                    $insertProductCategories = $db->prepare("INSERT INTO ProductCategories (serverID, parentID, name, slug, imageID, imageType) VALUES (?, ?, ?, ?, ?, ?)");
                    $insertProductCategories->execute(array(post("serverID"), post("parentID"), post("name"), convertURL(post("name")), $imageID, $upload->file_dst_name_ext));
                    echo alertSuccess("Kategori başarıyla eklendi!");
                  }
                  else {
                    echo alertError("Resim yüklenirken bir hata oluştu: ".$upload->error);
                  }
                }
              }
            }
          ?>
          <div class="card">
            <div class="card-body">
              <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group row">
                  <label for="inputName" class="col-sm-2 col-form-label">Kategori Adı:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputName" class="form-control" name="name" placeholder="Kategori adı yazınız.">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectServerID" class="col-sm-2 col-form-label">Sunucu:</label>
                  <div class="col-sm-10">
                    <?php $servers = $db->query("SELECT * FROM Servers"); ?>
                    <select id="selectServerID" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="serverID" <?php echo ($servers->rowCount() == 0) ? "disabled" : null; ?>>
                      <?php if ($servers->rowCount() > 0): ?>
                        <?php foreach ($servers as $readServers): ?>
                          <option value="<?php echo $readServers["id"]; ?>"><?php echo $readServers["name"]; ?></option>
                        <?php endforeach; ?>
                      <?php else: ?>
                        <option>Sunucu bulunamadı!</option>
                      <?php endif; ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectParentID" class="col-sm-2 col-form-label">Üst Kategori:</label>
                  <div class="col-sm-10">
                    <div id="c-loading" style="display: none; margin-top: 7px">Yükleniyor...</div>
                    <div id="product-categories">
                      <?php
                        $firstServer = $db->query("SELECT * FROM Servers ORDER BY id ASC LIMIT 1");
                        $readFirstServer = $firstServer->fetch();

                        $productCategories = $db->prepare("SELECT * FROM ProductCategories WHERE serverID = ?");
                        $productCategories->execute(array($readFirstServer["id"]));
                      ?>
                      <select id="selectParentID" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="parentID">
                        <option value="0">Kategorisiz</option>
                        <?php if ($productCategories->rowCount() > 0): ?>
                          <?php foreach ($productCategories as $readProductCategories): ?>
                            <option value="<?php echo $readProductCategories["id"]; ?>"><?php echo $readProductCategories["name"]; ?></option>
                          <?php endforeach; ?>
                        <?php endif; ?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="fileImage" class="col-sm-2 col-form-label">Resim:</label>
                  <div class="col-sm-10">
                    <div data-toggle="dropimage" class="dropimage">
                      <div class="di-thumbnail">
                        <img src="" alt="Ön İzleme">
                      </div>
                      <div class="di-select">
                        <label for="fileImage">Bir Resim Seçiniz</label>
                        <input type="file" id="fileImage" name="image" accept="image/*">
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo $csrf->input('insertProductCategories'); ?>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="submit" class="btn btn-rounded btn-success" name="insertProductCategories">Ekle</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'update' && get("id")): ?>
    <?php
      $productCategory = $db->prepare("SELECT PC.*, S.slug as serverSlug FROM ProductCategories PC INNER JOIN Servers S ON PC.serverID = S.id WHERE PC.id = ?");
      $productCategory->execute(array(get("id")));
      $readProductCategory = $productCategory->fetch();
    ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Kategori Düzenle</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/kategori">Kategori</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/kategori">Kategori Düzenle</a></li>
                      <li class="breadcrumb-item active" aria-current="page"><?php echo ($productCategory->rowCount() > 0) ? $readProductCategory["name"] : "Bulunamadı!"; ?></li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php if ($productCategory->rowCount() > 0): ?>
            <?php
              require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
              $csrf = new CSRF('csrf-sessions', 'csrf-token');
              if (isset($_POST["updateProductCategories"])) {
                if (!$csrf->validate('updateProductCategories')) {
                  echo alertError("Sistemsel bir sorun oluştu!");
                }
                else if (post("name") == null || post("serverID") == null || post("parentID") == null) {
                  echo alertError("Lütfen boş alan bırakmayınız!");
                }
                else {
                  if ($_FILES["image"]["size"] != null) {
                    require_once(__ROOT__."/apps/dashboard/private/packages/class/upload/upload.php");
                    $upload = new \Verot\Upload\Upload($_FILES["image"], "tr_TR");
                    $imageID = $readProductCategory["imageID"];
                    if ($upload->uploaded) {
                      $upload->allowed = array("image/*");
                      $upload->file_overwrite = true;
                      $upload->file_new_name_body = $imageID;
                      $upload->image_resize = true;
                      $upload->image_ratio_crop = true;
                      $upload->image_x = 360;
                      $upload->image_y = 360;
                      $upload->process(__ROOT__."/apps/main/public/assets/img/store/categories/");
                      if ($upload->processed) {
                        $updateProductCategories = $db->prepare("UPDATE ProductCategories SET imageType = ? WHERE id = ?");
                        $updateProductCategories->execute(array($upload->file_dst_name_ext, get("id")));
                      }
                      else {
                        echo alertError("Resim yüklenirken bir hata oluştu: ".$upload->error);
                      }
                    }
                  }
                  $updateProductCategories = $db->prepare("UPDATE ProductCategories SET serverID = ?, parentID = ?, name = ?, slug = ? WHERE id = ?");
                  $updateProductCategories->execute(array(post("serverID"), post("parentID"), post("name"), convertURL(post("name")), get("id")));
                  echo alertSuccess("Değişiklikler başarıyla kaydedildi!");
                }
              }
            ?>
            <div class="card">
              <div class="card-body">
                <form action="" method="post" enctype="multipart/form-data">
                  <div class="form-group row">
                    <label for="inputName" class="col-sm-2 col-form-label">Kategori Adı:</label>
                    <div class="col-sm-10">
                      <input type="text" id="inputName" class="form-control" name="name" placeholder="Kategori adı yazınız." value="<?php echo $readProductCategory["name"]; ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectServerID" class="col-sm-2 col-form-label">Sunucu:</label>
                    <div class="col-sm-10">
                      <?php
                        $servers = $db->query("SELECT * FROM Servers");
                      ?>
                      <select id="selectServerID" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="serverID" <?php echo ($servers->rowCount() == 0) ? "disabled" : null; ?>>
                        <?php if ($servers->rowCount() > 0): ?>
                          <?php foreach ($servers as $readServers): ?>
                            <option value="<?php echo $readServers["id"]; ?>" <?php echo (($readProductCategory["serverID"] == $readServers["id"]) ? 'selected="selected"' : null); ?>><?php echo $readServers["name"]; ?></option>
                          <?php endforeach; ?>
                        <?php else: ?>
                          <option>Sunucu bulunamadı!</option>
                        <?php endif; ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectParentID" class="col-sm-2 col-form-label">Üst Kategori:</label>
                    <div class="col-sm-10">
                      <div id="c-loading" style="display: none; margin-top: 7px">Yükleniyor...</div>
                      <div id="product-categories">
                        <?php
                          $productCategories = $db->prepare("SELECT * FROM ProductCategories WHERE id != ? AND serverID = ?");
                          $productCategories->execute(array($readProductCategory["id"], $readProductCategory["serverID"]));
                        ?>
                        <select id="selectParentID" class="form-control" data-toggle="select" data-minimum-results-for-search="-1" name="parentID">
                          <option value="0">Kategorisiz</option>
                          <?php if ($productCategories->rowCount() > 0): ?>
                            <?php foreach ($productCategories as $readProductCategories): ?>
                              <option value="<?php echo $readProductCategories["id"]; ?>" <?php echo (($readProductCategory["parentID"] == $readProductCategories["id"]) ? 'selected="selected"' : null); ?>><?php echo $readProductCategories["name"]; ?></option>
                            <?php endforeach; ?>
                          <?php endif; ?>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="fileImage" class="col-sm-2 col-form-label">Resim:</label>
                    <div class="col-sm-10">
                      <div data-toggle="dropimage" class="dropimage active">
                        <div class="di-thumbnail">
                          <img src="/apps/main/public/assets/img/store/categories/<?php echo $readProductCategory["imageID"].'.'.$readProductCategory["imageType"]; ?>" alt="Ön İzleme">
                        </div>
                        <div class="di-select">
                          <label for="fileImage">Bir Resim Seçiniz</label>
                          <input type="file" id="fileImage" name="image" accept="image/*">
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php echo $csrf->input('updateProductCategories'); ?>
                  <div class="clearfix">
                    <div class="float-right">
                      <a class="btn btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/magaza/kategori/sil/<?php echo $readProductCategory["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                        <i class="fe fe-trash-2"></i>
                      </a>
                      <a class="btn btn-rounded-circle btn-primary" href="/magaza/<?php echo $readProductCategory["serverSlug"]; ?>/<?php echo $readProductCategory["slug"]; ?>" rel="external" data-toggle="tooltip" data-placement="top" title="Görüntüle">
                        <i class="fe fe-eye"></i>
                      </a>
                      <button type="submit" class="btn btn-rounded btn-success" name="updateProductCategories">Değişiklikleri Kaydet</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'delete' && get("id")): ?>
    <?php
      $deleteProductCategory = $db->prepare("DELETE FROM ProductCategories WHERE id = ?");
      $deleteProductCategory->execute(array(get("id")));
      go("/yonetim-paneli/magaza/kategori");
    ?>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php elseif (get("target") == 'credit'): ?>
  <?php if (get("action") == 'send'): ?>
    <?php
      if (get("id")) {
        $account = $db->prepare("SELECT * FROM Accounts WHERE id = ?");
        $account->execute(array(get("id")));
        $readAccount = $account->fetch();
      }
    ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Kredi Gönder</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <?php if (get("id")): ?>
                        <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/kredi/gonder">Kredi Gönder</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo ($account->rowCount() > 0) ? $readAccount["realname"] : "Bulunamadı!"; ?></li>
                      <?php else: ?>
                        <li class="breadcrumb-item active" aria-current="page">Kredi Gönder</li>
                      <?php endif; ?>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php if (!get("id") || (get("id") && $account->rowCount() > 0)): ?>
            <?php
              require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
              $csrf = new CSRF('csrf-sessions', 'csrf-token');
              if (isset($_POST["insertCreditHistory"])) {
                if ((!get("id") && post("username") != null)) {
                  $account = $db->prepare("SELECT * FROM Accounts WHERE realname = ?");
                  $account->execute(array(post("username")));
                  $readAccount = $account->fetch();
                }
                if (!$csrf->validate('insertCreditHistory')) {
                  echo alertError("Sistemsel bir sorun oluştu!");
                }
                else if ((!get("id") && post("username") == null) || post("type") == null || post("price") == null) {
                  echo alertError("Lütfen boş alan bırakmayınız!");
                }
                else if (!get("id") && $account->rowCount() == 0) {
                  echo alertError("Kullanıcı bulunamadı!");
                }
                else {
                  if (post("type") == 3) {
                    $_POST["type"] = 2;
                  }
                  $insertCreditHistory = $db->prepare("INSERT INTO CreditHistory (accountID, paymentID, paymentAPI, paymentStatus, type, price, earnings, creationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                  $insertCreditHistory->execute(array($readAccount["id"], 0, post("paymentAPI"), 1, post("type"), post("price"), post("price"), date("Y-m-d H:i:s")));
                  $updateAccounts = $db->prepare("UPDATE Accounts SET credit = credit + ? WHERE id = ?");
                  $updateAccounts->execute(array(post("price"), $readAccount["id"]));
                  echo alertSuccess("Kredi başarıyla gönderildi!");
                }
              }
            ?>
            <div class="card">
              <div class="card-body">
                <form action="" method="post">
                  <div class="form-group row">
                    <?php if (get("id")): ?>
                      <label for="staticUsername" class="col-sm-2 col-form-label">Kullanıcı Adı:</label>
                      <div class="col-sm-10">
                        <a id="staticUsername" class="form-control-plaintext" href="/yonetim-paneli/hesap/goruntule/<?php echo $readAccount["id"]; ?>">
                          <?php echo $readAccount["realname"]; ?>
                        </a>
                      </div>
                    <?php else: ?>
                      <label for="inputUsername" class="col-sm-2 col-form-label">Kullanıcı Adı:</label>
                      <div class="col-sm-10">
                        <input type="text" id="inputUsername" class="form-control" name="username" placeholder="Kredi gönderilecek oyuncunun kullanıcı adını yazınız.">
                      </div>
                    <?php endif; ?>
                  </div>
                  <div class="form-group row">
                    <label for="inputPrice" class="col-sm-2 col-form-label">Gönderilecek Miktar:</label>
                    <div class="col-sm-10">
                      <div class="input-group input-group-merge">
                        <input type="number" id="inputPrice" class="form-control form-control-prepended" name="price" placeholder="Oyuncuya gönderilecek kredi miktarını yazınız.">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <span class="fa fa-try"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectAPIID" class="col-sm-2 col-form-label">Ödeme Altyapısı:</label>
                    <div class="col-sm-10">
                      <select id="selectAPIID" class="form-control" name="paymentAPI" data-toggle="select" data-minimum-results-for-search="-1">
                        <?php
                          $paymentSettings = $db->prepare("SELECT name, slug FROM PaymentSettings WHERE status = ? ORDER BY slug ASC");
                          $paymentSettings->execute(array(1));
                        ?>
                        <?php if ($paymentSettings->rowCount() > 0): ?>
                          <?php foreach ($paymentSettings as $readPaymentSettings): ?>
                            <option value="<?php echo $readPaymentSettings["slug"]; ?>"><?php echo $readPaymentSettings["name"]; ?></option>
                          <?php endforeach; ?>
                        <?php endif; ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="selectType" class="col-sm-2 col-form-label">Ödeme Yöntemi:</label>
                    <div class="col-sm-10">
                      <select id="selectType" class="form-control" name="type" data-toggle="select" data-minimum-results-for-search="-1">
                        <option value="1">Mobil Ödeme</option>
                        <option value="2">Kredi Kartı</option>
                        <option value="3" disabled="disabled">EFT</option>
                      </select>
                    </div>
                  </div>
                  <?php echo $csrf->input('insertCreditHistory'); ?>
                  <div class="clearfix">
                    <div class="float-right">
                      <button type="submit" class="btn btn-rounded btn-success" name="insertCreditHistory">Kredi Gönder</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          <?php else: ?>
            <?php echo alertError("Kullanıcı bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php elseif (get("target") == 'credit-charge-history'): ?>
  <?php if (get("action") == 'getAll'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Kredi Yükleme Geçmişi</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Kredi Yükleme Geçmişi</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            if (isset($_GET["page"])) {
              if (!is_numeric($_GET["page"])) {
                $_GET["page"] = 1;
              }
              $page = intval(get("page"));
            }
            else {
              $page = 1;
            }

            $visiblePageCount = 5;
            $limit = 50;

            $creditHistory = $db->prepare("SELECT CH.id FROM CreditHistory CH INNER JOIN Accounts A ON CH.accountID = A.id WHERE CH.type IN (?, ?) AND CH.paymentStatus = ?");
            $creditHistory->execute(array(1, 2, 1));
            $itemsCount = $creditHistory->rowCount();
            $pageCount = ceil($itemsCount/$limit);
            if ($page > $pageCount) {
              $page = 1;
            }
            $visibleItemsCount = $page * $limit - $limit;
            $creditHistory = $db->prepare("SELECT CH.*, A.realname FROM CreditHistory CH INNER JOIN Accounts A ON CH.accountID = A.id WHERE CH.type IN (?, ?) AND CH.paymentStatus = ? ORDER BY CH.id DESC LIMIT $visibleItemsCount, $limit");
            $creditHistory->execute(array(1, 2, 1));

            if (isset($_POST["query"])) {
              if (post("query") != null) {
                $creditHistory = $db->prepare("SELECT CH.*, A.realname FROM CreditHistory CH INNER JOIN Accounts A ON CH.accountID = A.id WHERE A.realname LIKE :search AND CH.type IN (:mobileType, :creditCardType) AND CH.paymentStatus = :paymentStatus ORDER BY CH.id DESC");
                $creditHistory->execute(array(
                  "search"          => '%'.post("query").'%',
                  "paymentStatus"   => 1,
                  "mobileType"      => 1,
                  "creditCardType"  => 2
                ));
              }
            }
          ?>
          <?php if ($creditHistory->rowCount() > 0): ?>
            <div class="card">
              <div class="card-header">
                <div class="row align-items-center">
                  <form action="" method="post" class="d-flex align-items-center w-100">
                    <div class="col">
                      <div class="row align-items-center">
                        <div class="col-auto pr-0">
                          <span class="fe fe-search text-muted"></span>
                        </div>
                        <div class="col">
                          <input type="search" class="form-control form-control-flush search" name="query" placeholder="Arama Yap (Kullanıcı)" value="<?php echo (isset($_POST["query"])) ? post("query"): null; ?>">
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <button type="submit" class="btn btn-sm btn-success">Ara</button>
                    </div>
                  </form>
                </div>
              </div>
              <div id="loader" class="card-body p-0 is-loading">
                <div id="spinner">
                  <div class="spinner-border" role="status">
                    <span class="sr-only">-/-</span>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-sm table-nowrap card-table">
                    <thead>
                      <tr>
                        <th class="text-center" style="width: 40px;">#ID</th>
                        <th>Kullanıcı Adı</th>
                        <th class="text-center">Miktar</th>
                        <th class="text-center">Kazanç</th>
                        <th class="text-center">Ödeme</th>
                        <th class="text-center">Altyapı</th>
                        <th>Tarih</th>
                        <th class="text-right">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody class="list">
                      <?php foreach ($creditHistory as $readCreditHistory): ?>
                        <tr>
                          <td class="text-center" style="width: 40px;">
                            #<?php echo $readCreditHistory["id"]; ?>
                          </td>
                          <td>
                            <a href="/yonetim-paneli/hesap/goruntule/<?php echo $readCreditHistory["accountID"]; ?>">
                              <?php echo $readCreditHistory["realname"]; ?>
                            </a>
                          </td>
                          <td class="text-center">
                            <?php echo ($readCreditHistory["type"] == 3 || $readCreditHistory["type"] == 5) ? '<span class="text-danger">-'.$readCreditHistory["price"].'</span>' : '<span class="text-success">+'.$readCreditHistory["price"].'</span>'; ?>
                          </td>
                          <td class="text-center">
                            <?php echo $readCreditHistory["earnings"]; ?>
                          </td>
                          <td class="text-center">
                            <?php if ($readCreditHistory["type"] == 1): ?>
                              <i class="fa fa-mobile" data-toggle="tooltip" data-placement="top" title="Mobil Ödeme"></i>
                            <?php elseif ($readCreditHistory["type"] == 2): ?>
                              <i class="fa fa-credit-card" data-toggle="tooltip" data-placement="top" title="Kredi Kartı Ödeme"></i>
                            <?php elseif ($readCreditHistory["type"] == 3): ?>
                              <i class="fa fa-paper-plane" data-toggle="tooltip" data-placement="top" title="Gönderim (Gönderen)"></i>
                            <?php elseif ($readCreditHistory["type"] == 4): ?>
                              <i class="fa fa-paper-plane" data-toggle="tooltip" data-placement="top" title="Gönderim (Alan)"></i>
                            <?php elseif ($readCreditHistory["type"] == 5): ?>
                              <i class="fa fa-ticket" data-toggle="tooltip" data-placement="top" title="Çarkıfelek (Bilet)"></i>
                            <?php elseif ($readCreditHistory["type"] == 6): ?>
                              <i class="fa fa-ticket" data-toggle="tooltip" data-placement="top" title="Çarkıfelek (Kazanç)"></i>
                            <?php else: ?>
                              <i class="fa fa-paper-plane"></i>
                            <?php endif; ?>
                          </td>
                          <td class="text-center">
                            <?php
                              $paymentAPI = $db->prepare("SELECT name FROM PaymentSettings WHERE slug = ?");
                              $paymentAPI->execute(array($readCreditHistory["paymentAPI"]));
                              $readPaymentAPI = $paymentAPI->fetch();

                              if ($paymentAPI->rowCount() > 0) {
                                echo $readPaymentAPI["name"];
                              }
                              else {
                                echo "Diğer";
                              }
                            ?>
                          </td>
                          <td>
                            <?php echo convertTime($readCreditHistory["creationDate"], 2, true); ?>
                          </td>
                          <td class="text-right">
                            <a class="btn btn-sm btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/magaza/kredi-yukleme-gecmisi/sil/<?php echo $readCreditHistory["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                              <i class="fe fe-trash-2"></i>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <?php if (post("query") == false): ?>
              <nav class="pt-3 pb-5" aria-label="Page Navigation">
                <ul class="pagination justify-content-center">
                  <li class="page-item <?php echo ($page == 1) ? "disabled" : null; ?>">
                    <a class="page-link" href="/yonetim-paneli/magaza/kredi-yukleme-gecmisi/<?php echo $page-1; ?>" tabindex="-1" aria-disabled="true"><i class="fa fa-angle-left"></i></a>
                  </li>
                  <?php for ($i = $page - $visiblePageCount; $i < $page + $visiblePageCount + 1; $i++): ?>
                    <?php if ($i > 0 and $i <= $pageCount): ?>
                      <li class="page-item <?php echo (($page == $i) ? "active" : null); ?>">
                        <a class="page-link" href="/yonetim-paneli/magaza/kredi-yukleme-gecmisi/<?php echo $i; ?>"><?php echo $i; ?></a>
                      </li>
                    <?php endif; ?>
                  <?php endfor; ?>
                  <li class="page-item <?php echo ($page == $pageCount) ? "disabled" : null; ?>">
                    <a class="page-link" href="/yonetim-paneli/magaza/kredi-yukleme-gecmisi/<?php echo $page+1; ?>"><i class="fa fa-angle-right"></i></a>
                  </li>
                </ul>
              </nav>
            <?php endif; ?>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'delete' && get("id")): ?>
    <?php
      $deleteCreditHistory = $db->prepare("DELETE FROM CreditHistory WHERE id = ?");
      $deleteCreditHistory->execute(array(get("id")));
      go("/yonetim-paneli/magaza/kredi-yukleme-gecmisi");
    ?>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php elseif (get("target") == 'credit-usage-history'): ?>
  <?php if (get("action") == 'getAll'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Kredi Kullanım Geçmişi</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Kredi Kullanım Geçmişi</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            if (isset($_GET["page"])) {
              if (!is_numeric($_GET["page"])) {
                $_GET["page"] = 1;
              }
              $page = intval(get("page"));
            }
            else {
              $page = 1;
            }

            $visiblePageCount = 5;
            $limit = 50;

            $creditHistory = $db->prepare("SELECT CH.id FROM CreditHistory CH INNER JOIN Accounts A ON CH.accountID = A.id WHERE CH.type != ? AND CH.type != ? AND CH.paymentStatus = ?");
            $creditHistory->execute(array(1, 2, 1));
            $itemsCount = $creditHistory->rowCount();
            $pageCount = ceil($itemsCount/$limit);
            if ($page > $pageCount) {
              $page = 1;
            }
            $visibleItemsCount = $page * $limit - $limit;
            $creditHistory = $db->prepare("SELECT CH.*, A.realname FROM CreditHistory CH INNER JOIN Accounts A ON CH.accountID = A.id WHERE CH.type != ? AND CH.type != ? AND CH.paymentStatus = ? ORDER BY CH.id DESC LIMIT $visibleItemsCount, $limit");
            $creditHistory->execute(array(1, 2, 1));

            if (isset($_POST["query"])) {
              if (post("query") != null) {
                $creditHistory = $db->prepare("SELECT CH.*, A.realname FROM CreditHistory CH INNER JOIN Accounts A ON CH.accountID = A.id WHERE A.realname LIKE :search AND CH.type != :mobileType AND CH.type != :creditCardType AND CH.paymentStatus = :paymentStatus ORDER BY CH.id DESC");
                $creditHistory->execute(array(
                  "search"        => '%'.post("query").'%',
                  "paymentStatus" => 1,
                  "mobileType"      => 1,
                  "creditCardType"  => 2
                ));
              }
            }
          ?>
          <?php if ($creditHistory->rowCount() > 0): ?>
            <div class="card">
              <div class="card-header">
                <div class="row align-items-center">
                  <form action="" method="post" class="d-flex align-items-center w-100">
                    <div class="col">
                      <div class="row align-items-center">
                        <div class="col-auto pr-0">
                          <span class="fe fe-search text-muted"></span>
                        </div>
                        <div class="col">
                          <input type="search" class="form-control form-control-flush search" name="query" placeholder="Arama Yap (Kullanıcı)" value="<?php echo (isset($_POST["query"])) ? post("query"): null; ?>">
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <button type="submit" class="btn btn-sm btn-success">Ara</button>
                    </div>
                  </form>
                </div>
              </div>
              <div id="loader" class="card-body p-0 is-loading">
                <div id="spinner">
                  <div class="spinner-border" role="status">
                    <span class="sr-only">-/-</span>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-sm table-nowrap card-table">
                    <thead>
                      <tr>
                        <th class="text-center" style="width: 40px;">#ID</th>
                        <th>Kullanıcı Adı</th>
                        <th class="text-center">Miktar</th>
                        <th class="text-center">Ödeme</th>
                        <th>Tarih</th>
                        <th class="text-right">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody class="list">
                      <?php foreach ($creditHistory as $readCreditHistory): ?>
                        <tr>
                          <td class="text-center" style="width: 40px;">
                            #<?php echo $readCreditHistory["id"]; ?>
                          </td>
                          <td>
                            <a href="/yonetim-paneli/hesap/goruntule/<?php echo $readCreditHistory["accountID"]; ?>">
                              <?php echo $readCreditHistory["realname"]; ?>
                            </a>
                          </td>
                          <td class="text-center">
                            <?php echo ($readCreditHistory["type"] == 3 || $readCreditHistory["type"] == 5) ? '<span class="text-danger">-'.$readCreditHistory["price"].'</span>' : '<span class="text-success">+'.$readCreditHistory["price"].'</span>'; ?>
                          </td>
                          <td class="text-center">
                            <?php if ($readCreditHistory["type"] == 1): ?>
                              <i class="fa fa-mobile" data-toggle="tooltip" data-placement="top" title="Mobil Ödeme"></i>
                            <?php elseif ($readCreditHistory["type"] == 2): ?>
                              <i class="fa fa-credit-card" data-toggle="tooltip" data-placement="top" title="Kredi Kartı Ödeme"></i>
                            <?php elseif ($readCreditHistory["type"] == 3): ?>
                              <i class="fa fa-paper-plane" data-toggle="tooltip" data-placement="top" title="Gönderim (Gönderen)"></i>
                            <?php elseif ($readCreditHistory["type"] == 4): ?>
                              <i class="fa fa-paper-plane" data-toggle="tooltip" data-placement="top" title="Gönderim (Alan)"></i>
                            <?php elseif ($readCreditHistory["type"] == 5): ?>
                              <i class="fa fa-ticket" data-toggle="tooltip" data-placement="top" title="Çarkıfelek (Bilet)"></i>
                            <?php elseif ($readCreditHistory["type"] == 6): ?>
                              <i class="fa fa-ticket" data-toggle="tooltip" data-placement="top" title="Çarkıfelek (Kazanç)"></i>
                            <?php else: ?>
                              <i class="fa fa-paper-plane"></i>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php echo convertTime($readCreditHistory["creationDate"], 2, true); ?>
                          </td>
                          <td class="text-right">
                            <a class="btn btn-sm btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/magaza/kredi-kullanim-gecmisi/sil/<?php echo $readCreditHistory["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                              <i class="fe fe-trash-2"></i>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <?php if (post("query") == false): ?>
              <nav class="pt-3 pb-5" aria-label="Page Navigation">
                <ul class="pagination justify-content-center">
                  <li class="page-item <?php echo ($page == 1) ? "disabled" : null; ?>">
                    <a class="page-link" href="/yonetim-paneli/magaza/kredi-kullanim-gecmisi/<?php echo $page-1; ?>" tabindex="-1" aria-disabled="true"><i class="fa fa-angle-left"></i></a>
                  </li>
                  <?php for ($i = $page - $visiblePageCount; $i < $page + $visiblePageCount + 1; $i++): ?>
                    <?php if ($i > 0 and $i <= $pageCount): ?>
                      <li class="page-item <?php echo (($page == $i) ? "active" : null); ?>">
                        <a class="page-link" href="/yonetim-paneli/magaza/kredi-kullanim-gecmisi/<?php echo $i; ?>"><?php echo $i; ?></a>
                      </li>
                    <?php endif; ?>
                  <?php endfor; ?>
                  <li class="page-item <?php echo ($page == $pageCount) ? "disabled" : null; ?>">
                    <a class="page-link" href="/yonetim-paneli/magaza/kredi-kullanim-gecmisi/<?php echo $page+1; ?>"><i class="fa fa-angle-right"></i></a>
                  </li>
                </ul>
              </nav>
            <?php endif; ?>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'delete' && get("id")): ?>
    <?php
      $deleteCreditHistory = $db->prepare("DELETE FROM CreditHistory WHERE id = ?");
      $deleteCreditHistory->execute(array(get("id")));
      go("/yonetim-paneli/magaza/kredi-kullanim-gecmisi");
    ?>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php elseif (get("target") == 'store-history'): ?>
  <?php if (get("action") == 'getAll'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Mağaza Geçmişi</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli/magaza/urun">Mağaza</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Mağaza Geçmişi</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            if (isset($_GET["page"])) {
              if (!is_numeric($_GET["page"])) {
                $_GET["page"] = 1;
              }
              $page = intval(get("page"));
            }
            else {
              $page = 1;
            }

            $visiblePageCount = 5;
            $limit = 50;

            $storeHistory = $db->query("SELECT SH.id FROM StoreHistory SH INNER JOIN Accounts A ON SH.accountID = A.id INNER JOIN Products P ON SH.productID = P.id INNER JOIN Servers S ON SH.serverID = S.id");
            $itemsCount = $storeHistory->rowCount();
            $pageCount = ceil($itemsCount/$limit);
            if ($page > $pageCount) {
              $page = 1;
            }
            $visibleItemsCount = $page * $limit - $limit;
            $storeHistory = $db->query("SELECT SH.*, A.realname, P.name as productName, S.name as serverName FROM StoreHistory SH INNER JOIN Accounts A ON SH.accountID = A.id INNER JOIN Products P ON SH.productID = P.id INNER JOIN Servers S ON SH.serverID = S.id ORDER BY SH.id DESC LIMIT $visibleItemsCount, $limit");

            if (isset($_POST["query"])) {
              if (post("query") != null) {
                $storeHistory = $db->prepare("SELECT SH.*, A.realname, P.name as productName, S.name as serverName FROM StoreHistory SH INNER JOIN Accounts A ON SH.accountID = A.id INNER JOIN Products P ON SH.productID = P.id INNER JOIN Servers S ON SH.serverID = S.id WHERE A.realname LIKE :search ORDER BY SH.id DESC");
                $storeHistory->execute(array(
                  "search" => '%'.post("query").'%'
                ));
              }
            }
          ?>
          <?php if ($storeHistory->rowCount() > 0): ?>
            <div class="card">
              <div class="card-header">
                <div class="row align-items-center">
                  <form action="" method="post" class="d-flex align-items-center w-100">
                    <div class="col">
                      <div class="row align-items-center">
                        <div class="col-auto pr-0">
                          <span class="fe fe-search text-muted"></span>
                        </div>
                        <div class="col">
                          <input type="search" class="form-control form-control-flush search" name="query" placeholder="Arama Yap (Kullanıcı)" value="<?php echo (isset($_POST["query"])) ? post("query"): null; ?>">
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <button type="submit" class="btn btn-sm btn-success">Ara</button>
                    </div>
                  </form>
                </div>
              </div>
              <div id="loader" class="card-body p-0 is-loading">
                <div id="spinner">
                  <div class="spinner-border" role="status">
                    <span class="sr-only">-/-</span>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-sm table-nowrap card-table">
                    <thead>
                      <tr>
                        <th class="text-center" style="width: 40px;">#ID</th>
                        <th>Kullanıcı Adı</th>
                        <th>Ürün</th>
                        <th>Sunucu</th>
                        <th>Tutar</th>
                        <th>Tarih</th>
                        <th class="text-right">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody class="list">
                      <?php foreach ($storeHistory as $readStoreHistory): ?>
                        <tr>
                          <td class="text-center" style="width: 40px;">
                            #<?php echo $readStoreHistory["id"]; ?>
                          </td>
                          <td>
                            <a href="/yonetim-paneli/hesap/goruntule/<?php echo $readStoreHistory["accountID"]; ?>">
                              <?php echo $readStoreHistory["realname"]; ?>
                            </a>
                          </td>
                          <td>
                            <?php echo $readStoreHistory["productName"]; ?>
                          </td>
                          <td>
                            <?php echo $readStoreHistory["serverName"]; ?>
                          </td>
                          <td>
                            <?php if ($readStoreHistory["price"] > 0): ?>
                              <?php echo $readStoreHistory["price"]; ?> kredi
                            <?php else: ?>
                              Ücretsiz
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php echo convertTime($readStoreHistory["creationDate"], 2, true); ?>
                          </td>
                          <td class="text-right">
                            <a class="btn btn-sm btn-rounded-circle btn-danger clickdelete" href="/yonetim-paneli/magaza/magaza-gecmisi/sil/<?php echo $readStoreHistory["id"]; ?>" data-toggle="tooltip" data-placement="top" title="Sil">
                              <i class="fe fe-trash-2"></i>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <?php if (post("query") == false): ?>
              <nav class="pt-3 pb-5" aria-label="Page Navigation">
                <ul class="pagination justify-content-center">
                  <li class="page-item <?php echo ($page == 1) ? "disabled" : null; ?>">
                    <a class="page-link" href="/yonetim-paneli/magaza/magaza-gecmisi/<?php echo $page-1; ?>" tabindex="-1" aria-disabled="true"><i class="fa fa-angle-left"></i></a>
                  </li>
                  <?php for ($i = $page - $visiblePageCount; $i < $page + $visiblePageCount + 1; $i++): ?>
                    <?php if ($i > 0 and $i <= $pageCount): ?>
                      <li class="page-item <?php echo (($page == $i) ? "active" : null); ?>">
                        <a class="page-link" href="/yonetim-paneli/magaza/magaza-gecmisi/<?php echo $i; ?>"><?php echo $i; ?></a>
                      </li>
                    <?php endif; ?>
                  <?php endfor; ?>
                  <li class="page-item <?php echo ($page == $pageCount) ? "disabled" : null; ?>">
                    <a class="page-link" href="/yonetim-paneli/magaza/magaza-gecmisi/<?php echo $page+1; ?>"><i class="fa fa-angle-right"></i></a>
                  </li>
                </ul>
              </nav>
            <?php endif; ?>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php elseif (get("action") == 'delete' && get("id")): ?>
    <?php
      $deleteStoreHistory = $db->prepare("DELETE FROM StoreHistory WHERE id = ?");
      $deleteStoreHistory->execute(array(get("id")));
      go("/yonetim-paneli/magaza/magaza-gecmisi");
    ?>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php else: ?>
  <?php go('/404'); ?>
<?php endif; ?>
