<?php
  if ($readAdmin["permission"] != 1) {
    go('/yonetim-paneli/hata/001');
  }
  require_once(__ROOT__.'/apps/dashboard/private/packages/class/extraresources/extraresources.php');
  $extraResourcesJS = new ExtraResources('js');
  if (get("target") == 'general' && get("action") == 'update') {
    $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/settings.general.js');
  }
  if (get("target") == 'system' && get("action") == 'update') {
    $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/settings.system.js');
  }
  if (get("target") == 'smtp' && get("action") == 'update') {
    $extraResourcesJS->addResource('/apps/dashboard/public/assets/js/settings.smtp.check.js');
  }
?>
<?php if (get("target") == 'general'): ?>
  <?php if (get("action") == 'update'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Genel Ayarlar</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Ayarlar</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Genel Ayarlar</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
            $csrf = new CSRF('csrf-sessions', 'csrf-token');
            if (isset($_POST["updateGeneralSettings"])) {
              if (post("footerFacebook") == null) {
                $_POST["footerFacebook"] = '0';
              }
              if (post("footerTwitter") == null) {
                $_POST["footerTwitter"] = '0';
              }
              if (post("footerInstagram") == null) {
                $_POST["footerInstagram"] = '0';
              }
              if (post("footerYoutube") == null) {
                $_POST["footerYoutube"] = '0';
              }
              if (post("footerDiscord") == null) {
                $_POST["footerDiscord"] = '0';
              }
              if (post("footerEmail") == null) {
                $_POST["footerEmail"] = '0';
              }
              if (post("footerPhone") == null) {
                $_POST["footerPhone"] = '0';
              }
              if (post("footerWhatsapp") == null) {
                $_POST["footerWhatsapp"] = '0';
              }
              if (post("footerAboutText") == null) {
                $_POST["footerAboutText"] = '0';
              }
              if (!$csrf->validate('updateGeneralSettings')) {
                echo alertError("Sistemsel bir sorun oluştu!");
              }
              else if (post("siteSlogan") == null || post("serverName") == null || post("serverIP") == null) {
                echo alertError("Lütfen gerekli alanları doldurunuz!");
              }
              else {
                if ($_FILES["favicon"]["size"] != null) {
                  require_once(__ROOT__."/apps/dashboard/private/packages/class/upload/upload.php");
                  $upload = new \Verot\Upload\Upload($_FILES["favicon"], "tr_TR");
                  if ($upload->uploaded) {
                    $upload->allowed = array("image/*");
                    $upload->file_overwrite = true;
                    $upload->file_new_name_body = "favicon";
                    $upload->image_convert = "png";
                    $upload->image_resize = true;
                    $upload->image_ratio_crop = true;
                    $upload->image_x = 64;
                    $upload->image_y = 64;
                    $upload->process(__ROOT__."/apps/main/public/assets/img/extras/");
                    if (!$upload->processed) {
                      echo alertError("Favicon yüklenirken bir hata oluştu: ".$upload->error);
                    }
                  }
                }
                if ($_FILES["logo"]["size"] != null) {
                  require_once(__ROOT__."/apps/dashboard/private/packages/class/upload/upload.php");
                  $upload = new \Verot\Upload\Upload($_FILES["logo"], "tr_TR");
                  if ($upload->uploaded) {
                    $upload->allowed = array("image/*");
                    $upload->file_overwrite = true;
                    $upload->file_new_name_body = "logo";
                    $upload->image_convert = "png";
                    $upload->process(__ROOT__."/apps/main/public/assets/img/extras/");
                    if (!$upload->processed) {
                      echo alertError("Logo yüklenirken bir hata oluştu: ".$upload->error);
                    }
                  }
                }

                $updateSettings = $db->prepare("UPDATE Settings SET siteSlogan = ?, serverName = ?, serverIP = ?, serverVersion = ?, siteTags = ?, siteDescription = ?, rules = ?, footerFacebook = ?, footerTwitter = ?, footerInstagram = ?, footerYoutube = ?, footerDiscord = ?, footerEmail = ?, footerPhone = ?, footerWhatsapp = ?, footerAboutText = ?, headerLogoType = ? WHERE id = ?");
                $updateSettings->execute(array(post("siteSlogan"), post("serverName"), post("serverIP"), post("serverVersion"), post("siteTags"), post("siteDescription"), filteredContent($_POST["rules"]), post("footerFacebook"), post("footerTwitter"), post("footerInstagram"), post("footerYoutube"), post("footerDiscord"), post("footerEmail"), post("footerPhone"), post("footerWhatsapp"), post("footerAboutText"), post("headerLogoType"), $readSettings["id"]));
                echo alertSuccess("Değişiklikler başarıyla kaydedildi!");
              }
            }
          ?>
          <div class="card">
            <div class="card-body">
              <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group row">
                  <label for="inputServerName" class="col-sm-2 col-form-label">Sunucu Adı:*</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputServerName" class="form-control" name="serverName" placeholder="Sunucu adını yazınız." value="<?php echo $readSettings["serverName"]; ?>" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputSiteSlogan" class="col-sm-2 col-form-label">Site Başlığı:*</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputSiteSlogan" class="form-control" name="siteSlogan" placeholder="Site başlığını yazınız." value="<?php echo $readSettings["siteSlogan"]; ?>" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputServerIP" class="col-sm-2 col-form-label">Sunucu IP:*</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputServerIP" class="form-control" name="serverIP" placeholder="Sunucu IP adresini yazınız." value="<?php echo $readSettings["serverIP"]; ?>" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputServerVersion" class="col-sm-2 col-form-label">Sunucu Sürümü:*</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputServerVersion" class="form-control" name="serverVersion" placeholder="Sunucu sürümünü yazınız." value="<?php echo $readSettings["serverVersion"]; ?>" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputSiteTags" class="col-sm-2 col-form-label">Google Etiket:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputTags" class="form-control" data-toggle="tagsinput" name="siteTags" placeholder="Google etiketlerini yazınız." value="<?php echo $readSettings["siteTags"]; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="textareaSiteDescription" class="col-sm-2 col-form-label">Google Açıklama:</label>
                  <div class="col-sm-10">
                    <textarea id="textareaSiteDescription" class="form-control" name="siteDescription" maxlength="155" placeholder="Google aramasında çıkması istediğiniz açıklamayı yazınız." rows="5"><?php echo $readSettings["siteDescription"]; ?></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputFooterFacebook" class="col-sm-2 col-form-label">Facebook URL:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputFooterFacebook" class="form-control" name="footerFacebook" placeholder="Facebook sayfanızın URL adresini yazınız." value="<?php echo ($readSettings["footerFacebook"] != '0') ? $readSettings["footerFacebook"] : null; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputFooterTwitter" class="col-sm-2 col-form-label">Twitter URL:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputFooterTwitter" class="form-control" name="footerTwitter" placeholder="Twitter sayfanızın URL adresini yazınız." value="<?php echo ($readSettings["footerTwitter"] != '0') ? $readSettings["footerTwitter"] : null; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputFooterInstagram" class="col-sm-2 col-form-label">Instagram URL:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputFooterInstagram" class="form-control" name="footerInstagram" placeholder="Instagram sayfanızın URL adresini yazınız." value="<?php echo ($readSettings["footerInstagram"] != '0') ? $readSettings["footerInstagram"] : null; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputFooterYoutube" class="col-sm-2 col-form-label">YouTube URL:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputFooterYoutube" class="form-control" name="footerYoutube" placeholder="YouTube kanalınızın URL adresini yazınız." value="<?php echo ($readSettings["footerYoutube"] != '0') ? $readSettings["footerYoutube"] : null; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputFooterDiscord" class="col-sm-2 col-form-label">Discord URL:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputFooterDiscord" class="form-control" name="footerDiscord" placeholder="Discord kanalınızın davet URL adresini yazınız." value="<?php echo ($readSettings["footerDiscord"] != '0') ? $readSettings["footerDiscord"] : null; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputFooterEmail" class="col-sm-2 col-form-label">E-Posta:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputFooterEmail" class="form-control" name="footerEmail" placeholder="İletişim alanı için e-posta adresinizi yazınız." value="<?php echo ($readSettings["footerEmail"] != '0') ? $readSettings["footerEmail"] : null; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputFooterPhone" class="col-sm-2 col-form-label">Telefon Numarası:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputFooterPhone" class="form-control" name="footerPhone" placeholder="İletişim alanı için telefon numaranızı yazınız." value="<?php echo ($readSettings["footerPhone"] != '0') ? $readSettings["footerPhone"] : null; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputFooterWhatsapp" class="col-sm-2 col-form-label">WhatsApp:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputFooterWhatsapp" class="form-control" name="footerWhatsapp" placeholder="İletişim alanı için WhatsApp numaranızı yazınız." value="<?php echo ($readSettings["footerWhatsapp"] != '0') ? $readSettings["footerWhatsapp"] : null; ?>">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="textareaFooterAboutText" class="col-sm-2 col-form-label">Hakkımızda:</label>
                  <div class="col-sm-10">
                    <textarea id="textareaFooterAboutText" class="form-control" name="footerAboutText" maxlength="255" placeholder="Footerdaki hakkımızda yazısını yazınız." rows="5"><?php echo ($readSettings["footerAboutText"] != '0') ? $readSettings["footerAboutText"] : null; ?></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="textareaRules" class="col-sm-2 col-form-label">Kurallar:</label>
                  <div class="col-sm-10">
                    <textarea id="textareaRules" class="form-control" data-toggle="textEditor" name="rules" placeholder="Kurallar sayfasında gösterilen yazı."><?php echo $readSettings["rules"] ?></textarea>
                    <small class="form-text text-muted pt-2"><strong>Sunucu Adı:</strong> %servername%</small>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectHeaderLogoType" class="col-sm-2 col-form-label">Sunucu Logo (Header):</label>
                  <div class="col-sm-10">
                    <select id="selectHeaderLogoType" class="form-control" name="headerLogoType" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="1" <?php echo ($readSettings["headerLogoType"] == 1) ? 'selected="selected"' : null; ?>>Yazı</option>
                      <option value="2" <?php echo ($readSettings["headerLogoType"] == 2) ? 'selected="selected"' : null; ?>>Resim</option>
                    </select>
                  </div>
                </div>
                <div id="headerLogoOptions" style="<?php echo (($readSettings["headerLogoType"] == 1) ? "display: none;" : (($readSettings["headerLogoType"] == 2) ? "display: block;" : "display: none;")); ?>">
                  <div class="form-group row">
                    <div class="col-sm-10 offset-sm-2">
                      <div data-toggle="dropimage" class="dropimage <?php echo (file_exists(__ROOT__."/apps/main/public/assets/img/extras/logo.png")) ? "active" : null; ?>">
                        <div class="di-thumbnail">
                          <img src="<?php echo (file_exists(__ROOT__."/apps/main/public/assets/img/extras/logo.png")) ? "/apps/main/public/assets/img/extras/logo.png" : null; ?>" alt="Ön İzleme">
                        </div>
                        <div class="di-select">
                          <label for="fileLogo">Bir Resim Seçiniz</label>
                          <input type="file" id="fileLogo" name="logo" accept="image/*">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="fileFavicon" class="col-sm-2 col-form-label">Sunucu Logo (Favicon):</label>
                  <div class="col-sm-10">
                    <div data-toggle="dropimage" class="dropimage <?php echo (file_exists(__ROOT__."/apps/main/public/assets/img/extras/favicon.png")) ? "active" : null; ?>">
                      <div class="di-thumbnail">
                        <img src="<?php echo (file_exists(__ROOT__."/apps/main/public/assets/img/extras/favicon.png")) ? "/apps/main/public/assets/img/extras/favicon.png" : null; ?>" alt="Ön İzleme">
                      </div>
                      <div class="di-select">
                        <label for="fileFavicon">Bir Resim Seçiniz</label>
                        <input type="file" id="fileFavicon" name="favicon" accept="image/*">
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo $csrf->input('updateGeneralSettings'); ?>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="submit" class="btn btn-rounded btn-success" name="updateGeneralSettings">Değişiklikleri Kaydet</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php elseif (get("target") == 'system'): ?>
  <?php if (get("action") == 'update'): ?>
    <?php
      $recaptchaPagesStatusJSON = $readSettings["recaptchaPagesStatus"];
      $recaptchaPagesStatus = json_decode($recaptchaPagesStatusJSON, true);
    ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Sistem Ayarları</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Ayarlar</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Sistem Ayarları</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
            $csrf = new CSRF('csrf-sessions', 'csrf-token');
            if (isset($_POST["updateSystemSettings"])) {
              if (post("analyticsStatus") == 0) {
                $_POST["analyticsUA"] = '0';
              }
              if (post("tawktoStatus") == 0) {
                $_POST["tawktoID"] = '0';
              }
              if (post("recaptchaStatus") == 0) {
                $_POST["recaptchaPublicKey"] = '0';
                $_POST["recaptchaPrivateKey"] = '0';
              }
              if (!$csrf->validate('updateSystemSettings')) {
                echo alertError("Sistemsel bir sorun oluştu!");
              }
              else if (post("debugModeStatus") == null || post("avatarAPI") == null || post("onlineAPI") == null || post("passwordType") == null || post("sslStatus") == null || post("maintenanceStatus") == null || post("topSalesStatus") == null || post("preloaderStatus") == null || post("analyticsStatus") == null || post("tawktoStatus") == null || post("recaptchaStatus") == null || post("minPay") == null || post("maxPay") == null || post("newsLimit") == null || post("registerLimit") == null || post("commentsStatus") == null) {
                echo alertError("Lütfen gerekli alanları doldurunuz!");
              }
              else {
                $recaptchaPagesStatusArray = $recaptchaPagesStatus;
                $recaptchaPagesStatusArray["loginPage"] = $_POST["recaptchaPagesStatus"][0];
                $recaptchaPagesStatusArray["registerPage"] = $_POST["recaptchaPagesStatus"][1];
                $recaptchaPagesStatusArray["recoverPage"] = $_POST["recaptchaPagesStatus"][2];
                $recaptchaPagesStatusArray["newsPage"] = $_POST["recaptchaPagesStatus"][3];
                $recaptchaPagesStatusArray["supportPage"] = $_POST["recaptchaPagesStatus"][4];
                $recaptchaPagesStatusJSON = json_encode($recaptchaPagesStatusArray);
                $updateSettings = $db->prepare("UPDATE Settings SET debugModeStatus = ?, avatarAPI = ?, onlineAPI = ?, passwordType = ?, sslStatus = ?, maintenanceStatus = ?, topSalesStatus = ?, preloaderStatus = ?, analyticsUA = ?, tawktoID = ?, recaptchaPagesStatus = ?, recaptchaPublicKey = ?, recaptchaPrivateKey = ?, minPay = ?, maxPay = ?, newsLimit = ?, registerLimit = ?, commentsStatus = ? WHERE id = ?");
                $updateSettings->execute(array(post("debugModeStatus"), post("avatarAPI"), post("onlineAPI"), post("passwordType"), post("sslStatus"), post("maintenanceStatus"), post("topSalesStatus"), post("preloaderStatus"), post("analyticsUA"), post("tawktoID"), $recaptchaPagesStatusJSON, post("recaptchaPublicKey"), post("recaptchaPrivateKey"), post("minPay"), post("maxPay"), post("newsLimit"), post("registerLimit"), post("commentsStatus"), $readSettings["id"]));
                echo alertSuccess("Değişiklikler başarıyla kaydedildi!");
              }
            }
          ?>
          <div class="card">
            <div class="card-body">
              <form action="" method="post">
                <div class="form-group row">
                  <label for="selectSSLStatus" class="col-sm-2 col-form-label">DEBUG Mod:*</label>
                  <div class="col-sm-10">
                    <select id="selectDebugModeStatus" class="form-control" name="debugModeStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["debugModeStatus"] == 0) ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["debugModeStatus"] == 1) ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectAvatarAPI" class="col-sm-2 col-form-label">Avatar API:*</label>
                  <div class="col-sm-10">
                    <select id="selectAvatarAPI" class="form-control" name="avatarAPI" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="1" <?php echo ($readSettings["avatarAPI"] == 1) ? 'selected="selected"' : null; ?>>minotar.net (Önerilen)</option>
                      <option value="2" <?php echo ($readSettings["avatarAPI"] == 2) ? 'selected="selected"' : null; ?>>cravatar.eu</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectOnlineAPI" class="col-sm-2 col-form-label">Online API:*</label>
                  <div class="col-sm-10">
                    <select id="selectOnlineAPI" class="form-control" name="onlineAPI" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="1" <?php echo ($readSettings["onlineAPI"] == 1) ? 'selected="selected"' : null; ?>>mcapi.us (Önerilen)</option>
                      <option value="2" <?php echo ($readSettings["onlineAPI"] == 2) ? 'selected="selected"' : null; ?>>mc-api.net</option>
                      <option value="3" <?php echo ($readSettings["onlineAPI"] == 3) ? 'selected="selected"' : null; ?>>mcapi.tc</option>
                      <option value="4" <?php echo ($readSettings["onlineAPI"] == 4) ? 'selected="selected"' : null; ?>>keyubu.net</option>
                      <option value="5" <?php echo ($readSettings["onlineAPI"] == 5) ? 'selected="selected"' : null; ?>>mcsrvstat.us</option>
                      <option value="6" <?php echo ($readSettings["onlineAPI"] == 6) ? 'selected="selected"' : null; ?>>mcsrvstat.us (Pocket Edition)</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectPasswordType" class="col-sm-2 col-form-label">Şifreleme Yöntemi:*</label>
                  <div class="col-sm-10">
                    <select id="selectPasswordType" class="form-control" name="passwordType" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="1" <?php echo ($readSettings["passwordType"] == 1) ? 'selected="selected"' : null; ?>>SHA256</option>
                      <option value="2" <?php echo ($readSettings["passwordType"] == 2) ? 'selected="selected"' : null; ?>>MD5</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectSSLStatus" class="col-sm-2 col-form-label">HTTPS Yönlendirme (SSL):*</label>
                  <div class="col-sm-10">
                    <select id="selectSSLStatus" class="form-control" name="sslStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["sslStatus"] == 0) ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["sslStatus"] == 1) ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectMaintenanceStatus" class="col-sm-2 col-form-label">Bakım Modu:*</label>
                  <div class="col-sm-10">
                    <select id="selectMaintenanceStatus" class="form-control" name="maintenanceStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["maintenanceStatus"] == 0) ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["maintenanceStatus"] == 1) ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectTopSalesStatus" class="col-sm-2 col-form-label">En Çok Satılan Ürünler:*</label>
                  <div class="col-sm-10">
                    <select id="selectTopSalesStatus" class="form-control" name="topSalesStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["topSalesStatus"] == 0) ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["topSalesStatus"] == 1) ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectPreloaderStatus" class="col-sm-2 col-form-label">Preloader:*</label>
                  <div class="col-sm-10">
                    <select id="selectPreloaderStatus" class="form-control" name="preloaderStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["preloaderStatus"] == 0) ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["preloaderStatus"] == 1) ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectCommentsStatus" class="col-sm-2 col-form-label">Yorumlar:*</label>
                  <div class="col-sm-10">
                    <select id="selectCommentsStatus" class="form-control" name="commentsStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["commentsStatus"] == 0) ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["commentsStatus"] == 1) ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectTawktoStatus" class="col-sm-2 col-form-label">Tawk.to (Canlı Sohbet):*</label>
                  <div class="col-sm-10">
                    <select id="selectTawktoStatus" class="form-control" name="tawktoStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["tawktoID"] == '0') ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["tawktoID"] != '0') ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div id="tawktoOptions" style="<?php echo ($readSettings["tawktoID"] == '0') ? "display: none;" : "display: block;"; ?>">
                  <div class="form-group row">
                    <label for="inputAnalyticsUA" class="col-sm-2 col-form-label">Tawkto Site ID:</label>
                    <div class="col-sm-10">
                      <input type="text" id="inputAnalyticsUA" class="form-control" name="tawktoID" placeholder="Tawk.to'dan aldığınız Site ID'yi giriniz." value="<?php echo ($readSettings["tawktoID"] != '0') ? $readSettings["tawktoID"] : null; ?>">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectAnalyticsStatus" class="col-sm-2 col-form-label">Google Analytics:*</label>
                  <div class="col-sm-10">
                    <select id="selectAnalyticsStatus" class="form-control" name="analyticsStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["analyticsUA"] == '0') ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["analyticsUA"] != '0') ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div id="analyticsOptions" style="<?php echo ($readSettings["analyticsUA"] == '0') ? "display: none;" : "display: block;"; ?>">
                  <div class="form-group row">
                    <label for="inputAnalyticsUA" class="col-sm-2 col-form-label">Google Analytics Kimlik:</label>
                    <div class="col-sm-10">
                      <input type="text" id="inputAnalyticsUA" class="form-control" name="analyticsUA" placeholder="Google Analytics sitesinden aldığınız mülk kimliğini giriniz. (Örn: UA-000001)" value="<?php echo ($readSettings["analyticsUA"] != '0') ? $readSettings["analyticsUA"] : null; ?>">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectRECAPTCHAStatus" class="col-sm-2 col-form-label">
                    Google reCAPTCHA:*
                    <a href="https://egitim.leaderos.com.tr/google-recaptcha" rel="external">
                      <i class="fa fa-info-circle text-primary"></i>
                    </a>
                  </label>
                  <div class="col-sm-10">
                    <select id="selectRECAPTCHAStatus" class="form-control" name="recaptchaStatus" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="0" <?php echo ($readSettings["recaptchaPublicKey"] == '0' || $readSettings["recaptchaPrivateKey"] == '0') ? 'selected="selected"' : null; ?>>Kapalı</option>
                      <option value="1" <?php echo ($readSettings["recaptchaPublicKey"] != '0' && $readSettings["recaptchaPrivateKey"] != '0') ? 'selected="selected"' : null; ?>>Açık</option>
                    </select>
                  </div>
                </div>
                <div id="recaptchaOptions" style="<?php echo ($readSettings["recaptchaPublicKey"] == '0' || $readSettings["recaptchaPrivateKey"] == '0') ? "display: none;" : "display: block;"; ?>">
                  <div class="form-group row">
                    <label for="inputRECAPTCHAPagesStatus" class="col-sm-2 col-form-label">reCAPTCHA Aktif Sayfalar:</label>
                    <div class="d-flex">
                      <label for="switchLoginPage" class="col-auto col-form-label">Giriş:</label>
                      <div class="col col-form-label">
                        <div class="custom-control custom-switch">
                          <input type="hidden" name="recaptchaPagesStatus[]">
                          <input type="checkbox" id="switchLoginPage" class="custom-control-input" <?php echo ($recaptchaPagesStatus["loginPage"] == 1) ? "checked" : null; ?>>
                          <label for="switchLoginPage" class="custom-control-label"></label>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex">
                      <label for="switchRegisterPage" class="col-auto col-form-label">Kayıt:</label>
                      <div class="col col-form-label">
                        <div class="custom-control custom-switch">
                          <input type="hidden" name="recaptchaPagesStatus[]">
                          <input type="checkbox" id="switchRegisterPage" class="custom-control-input" <?php echo ($recaptchaPagesStatus["registerPage"] == 1) ? "checked" : null; ?>>
                          <label for="switchRegisterPage" class="custom-control-label"></label>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex">
                      <label for="switchRecoverPage" class="col-auto col-form-label">Şifre Sıfırlama:</label>
                      <div class="col col-form-label">
                        <div class="custom-control custom-switch">
                          <input type="hidden" name="recaptchaPagesStatus[]">
                          <input type="checkbox" id="switchRecoverPage" class="custom-control-input" <?php echo ($recaptchaPagesStatus["recoverPage"] == 1) ? "checked" : null; ?>>
                          <label for="switchRecoverPage" class="custom-control-label"></label>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex">
                      <label for="switchNewsPage" class="col-auto col-form-label">Haber:</label>
                      <div class="col col-form-label">
                        <div class="custom-control custom-switch">
                          <input type="hidden" name="recaptchaPagesStatus[]">
                          <input type="checkbox" id="switchNewsPage" class="custom-control-input" <?php echo ($recaptchaPagesStatus["newsPage"] == 1) ? "checked" : null; ?>>
                          <label for="switchNewsPage" class="custom-control-label"></label>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex">
                      <label for="switchSupportPage" class="col-auto col-form-label">Destek:</label>
                      <div class="col col-form-label">
                        <div class="custom-control custom-switch">
                          <input type="hidden" name="recaptchaPagesStatus[]">
                          <input type="checkbox" id="switchSupportPage" class="custom-control-input" <?php echo ($recaptchaPagesStatus["supportPage"] == 1) ? "checked" : null; ?>>
                          <label for="switchSupportPage" class="custom-control-label"></label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputRECAPTCHAPublicKey" class="col-sm-2 col-form-label">reCAPTCHA Site Anahtarı:</label>
                    <div class="col-sm-10">
                      <input type="text" id="inputRECAPTCHAPublicKey" class="form-control" name="recaptchaPublicKey" placeholder="Google reCAPTCHA sitesinden aldığınız Site Anahtarı'nı giriniz." value="<?php echo ($readSettings["recaptchaPublicKey"] != '0') ? $readSettings["recaptchaPublicKey"] : null; ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputRECAPTCHAPrivateKey" class="col-sm-2 col-form-label">reCAPTCHA Gizli Anahtar:</label>
                    <div class="col-sm-10">
                      <input type="text" id="inputRECAPTCHAPrivateKey" class="form-control" name="recaptchaPrivateKey" placeholder="Google reCAPTCHA sitesinden aldığınız Gizli Anahtar'ı giriniz." value="<?php echo ($readSettings["recaptchaPrivateKey"] != '0') ? $readSettings["recaptchaPrivateKey"] : null; ?>">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputMinPay" class="col-sm-2 col-form-label">Minimum Ödeme Tutarı:</label>
                  <div class="col-sm-10">
                    <input type="number" id="inputMinPay" class="form-control" name="minPay" placeholder="Kredi yükleme ekranında kabul edilen minimum ödeme tutarını yazınız." value="<?php echo $readSettings["minPay"]; ?>" min="1" max="99999">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputMaxPay" class="col-sm-2 col-form-label">Maksimum Ödeme Tutarı:</label>
                  <div class="col-sm-10">
                    <input type="number" id="inputMaxPay" class="form-control" name="maxPay" placeholder="Kredi yükleme ekranında kabul edilen maksimum ödeme tutarını yazınız." value="<?php echo $readSettings["maxPay"]; ?>" min="1" max="99999">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectNewsLimit" class="col-sm-2 col-form-label">Haber Yazısı Limit (Her Sayfa):*</label>
                  <div class="col-sm-10">
                    <select id="selectNewsLimit" class="form-control" name="newsLimit" data-toggle="select" data-minimum-results-for-search="-1">
                      <?php
                        for ($i=1; $i <= 12; $i++) {
                          if ($i % 3 == 0) {
                            if ($readSettings["newsLimit"] == $i) {
                              echo '<option value="'.$i.'" selected>'.$i.'</option>';
                            }
                            else {
                              echo '<option value="'.$i.'">'.$i.'</option>';
                            }
                          }
                        }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectRegisterLimit" class="col-sm-2 col-form-label">Kayıt Limit:*</label>
                  <div class="col-sm-10">
                    <select id="selectRegisterLimit" class="form-control" name="registerLimit" data-toggle="select" data-minimum-results-for-search="-1">
                      <?php
                        for ($i=1; $i <= 3; $i++) {
                          if ($readSettings["registerLimit"] == $i) {
                            echo '<option value="'.$i.'" selected>'.$i.'</option>';
                          }
                          else {
                            echo '<option value="'.$i.'">'.$i.'</option>';
                          }
                        }
                        if ($readSettings["registerLimit"] == 0) {
                          echo '<option value="0" selected>Sınırsız</option>';
                        }
                        else {
                          echo '<option value="0">Sınırsız</option>';
                        }
                      ?>
                    </select>
                  </div>
                </div>
                <?php echo $csrf->input('updateSystemSettings'); ?>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="submit" class="btn btn-rounded btn-success" name="updateSystemSettings">Değişiklikleri Kaydet</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php elseif (get("target") == 'smtp'): ?>
  <?php if (get("action") == 'update'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">SMTP Ayarları</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Ayarlar</a></li>
                      <li class="breadcrumb-item active" aria-current="page">SMTP Ayarları</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
            $csrf = new CSRF('csrf-sessions', 'csrf-token');
            if (isset($_POST["updateSMTPSettings"])) {
              if (!$csrf->validate('updateSMTPSettings')) {
                echo alertError("Sistemsel bir sorun oluştu!");
              }
              else if (post("smtpServer") == null || post("smtpPort") == null || post("smtpSecure") == null || post("smtpUsername") == null || post("smtpPassword") == null) {
                echo alertError("Lütfen gerekli alanları doldurunuz!");
              }
              else {
                $updateSettings = $db->prepare("UPDATE Settings SET smtpServer = ?, smtpPort = ?, smtpSecure = ?, smtpUsername = ?, smtpPassword = ? WHERE id = ?");
                $updateSettings->execute(array(post("smtpServer"), post("smtpPort"), post("smtpSecure"), post("smtpUsername"), post("smtpPassword"), $readSettings["id"]));
                echo alertSuccess("Değişiklikler başarıyla kaydedildi!");
              }
            }
          ?>
          <div class="card">
            <div class="card-body">
              <form action="" method="post">
                <div class="form-group row">
                  <label for="inputSMTPServer" class="col-sm-2 col-form-label">SMTP Sunucu:</label>
                  <div class="col-sm-10">
                    <input type="text" id="inputSMTPServer" class="form-control" name="smtpServer" placeholder="SMTP sunucu adresini giriniz. (Örn: mail.leaderos.info)" value="<?php echo $readSettings["smtpServer"]; ?>" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputSMTPPort" class="col-sm-2 col-form-label">SMTP Port:</label>
                  <div class="col-sm-10">
                    <input type="number" id="inputSMTPPort" class="form-control" name="smtpPort" placeholder="SMTP sunucu adresini giriniz. (Örn: 587)" value="<?php echo $readSettings["smtpPort"]; ?>" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="selectSMTPSecure" class="col-sm-2 col-form-label">SMTP Güvenlik Seçeneği:</label>
                  <div class="col-sm-10">
                    <select id="selectSMTPSecure" class="form-control" name="smtpSecure" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="1" <?php echo ($readSettings["smtpSecure"] == 1) ? 'selected="selected"' : null; ?>>SSL</option>
                      <option value="2" <?php echo ($readSettings["smtpSecure"] == 2) ? 'selected="selected"' : null; ?>>TLS</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputSMTPUsername" class="col-sm-2 col-form-label">SMTP Email Adresi:</label>
                  <div class="col-sm-10">
                    <input type="email" id="inputSMTPUsername" class="form-control" name="smtpUsername" placeholder="SMTP email adresini giriniz. (Örn: destek@leaderos.info)" value="<?php echo $readSettings["smtpUsername"]; ?>" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputSMTPPassword" class="col-sm-2 col-form-label">SMTP Email Şifresi:</label>
                  <div class="col-sm-10">
                    <input type="password" id="inputSMTPPassword" class="form-control" name="smtpPassword" placeholder="SMTP email şifresini giriniz. (Örn: emailsifresi)" value="<?php echo $readSettings["smtpPassword"]; ?>" required>
                  </div>
                </div>
                <?php echo $csrf->input('updateSMTPSettings'); ?>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="button" id="testSMTP" class="btn btn-rounded btn-info">
                      <div class="spinner-grow spinner-grow-sm mr-2" role="status" style="display: none;">
                        <span class="sr-only">-/-</span>
                      </div>
                      <span>Bağlantıyı Kontrol Et</span>
                    </button>
                    <button type="submit" class="btn btn-rounded btn-success" name="updateSMTPSettings">Değişiklikleri Kaydet</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php elseif (get("target") == 'language'): ?>
  <?php if (get("action") == 'update'): ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="header">
            <div class="header-body">
              <div class="row align-items-center">
                <div class="col">
                  <h2 class="header-title">Dil Ayarları</h2>
                </div>
                <div class="col-auto">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Yönetim Paneli</a></li>
                      <li class="breadcrumb-item"><a href="/yonetim-paneli">Ayarlar</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Dil Ayarları</li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <?php
            require_once(__ROOT__."/apps/main/private/packages/class/csrf/csrf.php");
            $csrf = new CSRF('csrf-sessions', 'csrf-token');
            if (isset($_POST["updateLanguageSettings"])) {
              if (!$csrf->validate('updateLanguageSettings')) {
                echo alertError("Sistemsel bir sorun oluştu!");
              }
              else if (post("languageID") == null) {
                echo alertError("Lütfen gerekli alanları doldurunuz!");
              }
              else {
                $updateSettings = $db->prepare("UPDATE Settings SET languageID = ? WHERE id = ?");
                $updateSettings->execute(array(post("languageID"), $readSettings["id"]));
                echo alertSuccess("Değişiklikler başarıyla kaydedildi!");
              }
            }
          ?>
          <div class="card">
            <div class="card-body">
              <form action="" method="post">
                <div class="form-group row">
                  <label for="selectLanguageID" class="col-sm-2 col-form-label">Dil:</label>
                  <div class="col-sm-10">
                    <select id="selectLanguageID" class="form-control" name="languageID" data-toggle="select" data-minimum-results-for-search="-1">
                      <option value="1" <?php echo ($readSettings["languageID"] == 1) ? 'selected="selected"' : null; ?>>English</option>
                      <option value="2" <?php echo ($readSettings["languageID"] == 2) ? 'selected="selected"' : null; ?>>Türkçe</option>
                    </select>
                  </div>
                </div>
                <?php echo $csrf->input('updateLanguageSettings'); ?>
                <div class="clearfix">
                  <div class="float-right">
                    <button type="submit" class="btn btn-rounded btn-success" name="updateLanguageSettings">Değişiklikleri Kaydet</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php else: ?>
    <?php go('/404'); ?>
  <?php endif; ?>
<?php else: ?>
  <?php go('/404'); ?>
<?php endif; ?>
