<footer class="footer">
	<div class="row">
		<div class="col">
			Tüm hakları saklıdır! &copy; <?php echo date("Y"); ?>
		</div>
		<div class="col-auto">
			<copyright data-toggle="tooltip" data-placement="top" title="Yazılım: FIRAT KAYA">
				<a href="https://www.leaderos.com.tr/" rel="external">
					LEADEROS <?php echo ("v".VERSION); ?>
				</a>
			</copyright>
		</div>
	</div>
</footer>
