<?php
	header('Location: /404');
	exit();
?>