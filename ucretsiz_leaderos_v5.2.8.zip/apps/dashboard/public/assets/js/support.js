$(document).ready(function() {
  var element = $("#messagesBox");
  element.scrollTop(element.prop("scrollHeight"));
});
