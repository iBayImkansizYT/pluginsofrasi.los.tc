$(window).on("load", function() {
  $("#loader").removeClass("is-loading");
  $("#spinner").css("display", "none");
});
