$(document).ready(function() {
  swal.fire({
    type: "warning",
    title: "UYARI!",
    html: alertText,
    confirmButtonColor: "#02b875",
    confirmButtonText: "Tamam"
  });
});
