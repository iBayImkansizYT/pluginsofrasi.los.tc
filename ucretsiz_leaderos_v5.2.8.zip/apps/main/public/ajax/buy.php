<?php
  define("__ROOT__", $_SERVER["DOCUMENT_ROOT"]);
  require_once(__ROOT__."/apps/main/private/config/settings.php");
  if (isset($_SESSION["login"])) {
    if (post("productID") != null) {
      $product = $db->prepare("SELECT P.*, S.ip as serverIP, S.consoleID, S.consolePort, S.consolePassword, S.name as serverName FROM Products P INNER JOIN Servers S ON P.serverID = S.id WHERE P.id = ?");
      $product->execute(array(post("productID")));
      $readProduct = $product->fetch();

      $consoleIP = $readProduct["serverIP"];
      $consoleID = $readProduct["consoleID"];
      $consolePort = $readProduct["consolePort"];
      $consolePassword = $readProduct["consolePassword"];
      $consoleTimeout = 3;

      if ($consoleID == 1) {
        require_once(__ROOT__."/apps/main/private/packages/class/websend/websend.php");
        $console = new Websend($consoleIP, $consolePort);
        $console->password = $consolePassword;
      }
      else if ($consoleID == 2) {
        require_once(__ROOT__."/apps/main/private/packages/class/rcon/rcon.php");
        $console = new Rcon($consoleIP, $consolePort, $consolePassword, $consoleTimeout);
      }
      else if ($consoleID == 3) {
        require_once(__ROOT__."/apps/dashboard/private/packages/class/websender/websender.php");
        $console = new Websender($consoleIP, $consolePassword, $consolePort);
      }
      else {
        require_once(__ROOT__."/apps/main/private/packages/class/websend/websend.php");
        $console = new Websend($consoleIP, $consolePort);
        $console->password = $consolePassword;
      }

      if (@$console->connect()) {
        $discountedPriceStatus = ($readProduct["discountedPrice"] != 0 && ($readProduct["discountExpiryDate"] > date("Y-m-d H:i:s") || $readProduct["discountExpiryDate"] == '1000-01-01 00:00:00'));
        if ($discountedPriceStatus == true) {
          $productPrice = $readProduct["discountedPrice"];
        }
        else {
          $productPrice = $readProduct["price"];
        }

        if ($readAccount["credit"] >= $productPrice) {
          $insertStoreHistory = $db->prepare("INSERT INTO StoreHistory (accountID, productID, serverID, price, creationDate) VALUES (?, ?, ?, ?, ?)");
          $insertStoreHistory->execute(array($readAccount["id"], $readProduct["id"], $readProduct["serverID"], $productPrice, date("Y-m-d H:i:s")));
          $updateCredit = $db->prepare("UPDATE Accounts SET credit = credit - ? WHERE id = ?");
          $updateCredit->execute(array($productPrice, $readAccount["id"]));
          $productCommands = $db->prepare("SELECT PC.command FROM ProductCommands PC INNER JOIN Products P ON PC.productID = P.id WHERE PC.productID = ?");
          $productCommands->execute(array($readProduct["id"]));
          foreach ($productCommands as $readProductCommands) {
            $console->sendCommand(str_replace("%username%", $readAccount["realname"], $readProductCommands["command"]));
          }
          $console->disconnect();
          die("successful");
        }
        else {
          die("unsuccessful");
        }
      }
      else {
        die("error");
      }
    }
    else {
      die("error");
    }
  }
  else {
    die("error");
  }
?>
