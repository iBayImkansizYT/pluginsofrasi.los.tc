<?php
  define('INSTALL_STATUS', false);
  define('VERSION', '5.2.8');
  define('BUILD_NUMBER', 528);
?>
