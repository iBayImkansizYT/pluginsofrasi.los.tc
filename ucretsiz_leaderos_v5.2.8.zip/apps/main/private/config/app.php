<?php
  define('APP_KEY', 'KEY');
?>
