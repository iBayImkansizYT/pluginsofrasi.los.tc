<?php
	if (get("page")) {
		if (!is_numeric(get("page"))) {
			$_GET["page"] = 1;
		}
		$page = intval(get("page"));
	}
	else {
		$page = 1;
	}
	if (get("category")) {
		$itemsCount = $db->prepare("SELECT N.id from News N INNER JOIN NewsCategories NC ON N.categoryID = NC.id WHERE NC.slug = ?");
		$itemsCount->execute(array(get("category")));
		$itemsCount = $itemsCount->rowCount();
		$requestURL = '/kategori/'.get("category");
	}
	else if (get("tag")) {
		$itemsCount = $db->prepare("SELECT N.id from News N INNER JOIN NewsTags NT ON N.id = NT.newsID WHERE NT.slug = ?");
		$itemsCount->execute(array(get("tag")));
		$itemsCount = $itemsCount->rowCount();
		$requestURL = '/etiket/'.get("tag");
	}
	else {
		$itemsCount = $db->query("SELECT id from News");
		$itemsCount = $itemsCount->rowCount();
		$requestURL = '/haberler';
	}
	$pageCount = ceil($itemsCount/$newsLimit);
	if ($page > $pageCount) {
		$page = 1;
	}
	$visibleItemsCount = $page * $newsLimit - $newsLimit;
	$visiblePageCount = 5;
?>
<section class="section news-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<nav aria-label="breadcrumb">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="/">Ana Sayfa</a></li>
						<?php if (get("category")): ?>
							<?php
								$newsCategory = $db->prepare("SELECT name FROM NewsCategories WHERE slug = ?");
								$newsCategory->execute(array(get("category")));
								$readNewsCategory = $newsCategory->fetch();
							?>
							<li class="breadcrumb-item"><a href="/">Haberler</a></li>
							<li class="breadcrumb-item"><a href="/">Kategori</a></li>
							<li class="breadcrumb-item active" aria-current="page"><?php echo (($newsCategory->rowCount() > 0) ? $readNewsCategory["name"] : 'Bulunamadı!'); ?></li>
						<?php elseif (get("tag")): ?>
							<?php
								$newsTag = $db->prepare("SELECT name FROM NewsTags WHERE slug = ?");
								$newsTag->execute(array(get("tag")));
								$readNewsTag = $newsTag->fetch();
							?>
							<li class="breadcrumb-item"><a href="/">Haberler</a></li>
							<li class="breadcrumb-item"><a href="/">Etiket</a></li>
							<li class="breadcrumb-item active" aria-current="page"><?php echo (($newsTag->rowCount() > 0) ? $readNewsTag["name"] : 'Bulunamadı!'); ?></li>
						<?php else: ?>
							<li class="breadcrumb-item active" aria-current="page">Haberler</li>
						<?php endif; ?>
					</ol>
				</nav>
			</div>
			<?php
				if (get("category")) {
					$news = $db->prepare("SELECT N.*, NC.name as categoryName, NC.slug as categorySlug from News N INNER JOIN NewsCategories NC ON N.categoryID = NC.id INNER JOIN Accounts A ON N.accountID = A.id WHERE NC.slug = ? ORDER BY N.id DESC LIMIT $visibleItemsCount, $newsLimit");
					$news->execute(array(get("category")));
				}
				else if (get("tag")) {
					$news = $db->prepare("SELECT N.*, NC.name as categoryName, NC.slug as categorySlug from News N INNER JOIN NewsCategories NC ON N.categoryID = NC.id INNER JOIN NewsTags NT ON N.id = NT.newsID INNER JOIN Accounts A ON N.accountID = A.id WHERE NT.slug = ? ORDER BY N.id DESC LIMIT $visibleItemsCount, $newsLimit");
					$news->execute(array(get("tag")));
				}
				else {
					$news = $db->query("SELECT N.*, NC.name as categoryName, NC.slug as categorySlug from News N INNER JOIN NewsCategories NC ON N.categoryID = NC.id INNER JOIN Accounts A ON N.accountID = A.id ORDER BY N.id DESC LIMIT $visibleItemsCount, $newsLimit");
					$news->execute();
				}
			?>
			<?php if ($news->rowCount() > 0): ?>
				<?php foreach ($news as $readNews): ?>
					<?php
						$newsComments = $db->prepare("SELECT * FROM NewsComments WHERE newsID = ? AND status = ? ORDER BY id DESC");
						$newsComments->execute(array($readNews["id"], 1));
					?>
					<div class="col-md-4">
						<article class="news">
							<div class="card">
								<div class="img-container">
									<a class="img-card" href="/haber/<?php echo $readNews["id"]; ?>/<?php echo $readNews["slug"]; ?>">
										<img class="card-img-top lazyload" data-src="/apps/main/public/assets/img/news/<?php echo $readNews["imageID"].'.'.$readNews["imageType"]; ?>" src="/apps/main/public/assets/img/loaders/news.png" alt="<?php echo $serverName." Haber - ".$readNews["title"]; ?>">
									</a>
									<div class="img-card-tl">
										<a href="/kategori/<?php echo $readNews["categorySlug"]; ?>">
											<span class="theme-color badge badge-pill badge-primary"><?php echo $readNews["categoryName"]; ?></span>
										</a>
										<a href="/haber/<?php echo $readNews["id"]; ?>/<?php echo $readNews["slug"]; ?>">
											<span class="theme-color badge badge-pill badge-primary"><i class="fa fa-eye"></i> <?php echo $readNews["views"]; ?></span>
										</a>
										<a href="/haber/<?php echo $readNews["id"]; ?>/<?php echo $readNews["slug"]; ?>">
											<span class="theme-color badge badge-pill badge-primary"><i class="fa fa-comments"></i> <?php echo $newsComments->rowCount(); ?></span>
										</a>
									</div>
									<div class="img-card-tr">
										<a href="/haber/<?php echo $readNews["id"]; ?>/<?php echo $readNews["slug"]; ?>">
											<span class="theme-color badge badge-pill badge-primary"><?php echo convertTime($readNews["creationDate"], 1); ?></span>
										</a>
									</div>
									<div class="img-card-bottom">
										<h5 class="mb-0">
											<a class="text-white" href="/haber/<?php echo $readNews["id"]; ?>/<?php echo $readNews["slug"]; ?>">
												<?php echo $readNews["title"]; ?>
											</a>
										</h5>
									</div>
								</div>
								<div class="card-body">
									<p class="card-text">
										<?php echo showEmoji(limitedContent(strip_tags($readNews["content"]), 240)); ?>
									</p>
									<a class="theme-color btn btn-primary w-100" href="/haber/<?php echo $readNews["id"]; ?>/<?php echo $readNews["slug"]; ?>">DEVAMINI OKU</a>
								</div>
							</div>
						</article>
					</div>
				<?php endforeach; ?>
				<div class="col-md-12 d-flex justify-content-center">
					<nav class="pages" aria-label="Sayfalar">
						<ul class="pagination">
							<li class="page-item <?php echo ($page == 1) ? "disabled" : null; ?>">
								<a class="page-link" href="<?php echo $requestURL.'/'.($page-1); ?>" tabindex="-1">
									<i class="fa fa-angle-double-left"></i>
								</a>
							</li>
							<?php for ($i = $page - $visiblePageCount; $i < $page + $visiblePageCount + 1; $i++): ?>
								<?php if ($i > 0 and $i <= $pageCount): ?>
									<li class="page-item <?php echo (($page == $i) ? "active" : null); ?>">
										<a class="page-link" href="<?php echo $requestURL.'/'.$i; ?>"><?php echo $i; ?></a>
									</li>
								<?php endif; ?>
							<?php endfor; ?>
							<li class="page-item <?php echo ($page == $pageCount) ? "disabled" : null; ?>">
								<a class="page-link" href="<?php echo $requestURL.'/'.($page+1); ?>">
									<i class="fa fa-angle-double-right"></i>
								</a>
							</li>
						</ul>
					</nav>
				</div>
			<?php else : ?>
				<div class="col-md-12">
					<?php echo alertError("Haber bulunamadı!"); ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
