<?php
  $servers = $db->query("SELECT * FROM Servers");

  if (get("action") == "getAll") {
    if ($servers->rowCount() == 1) {
      go("/magaza/".$servers->fetch()["slug"]);
    }
  }
  if (get("action") == "get") {
    if (get("server")) {
      $thisServer = $db->prepare("SELECT * FROM Servers WHERE slug = ?");
      $thisServer->execute(array(get("server")));
      $readThisServer = $thisServer->fetch();
      if (get("category")) {
        $thisCategory = $db->prepare("SELECT * FROM ProductCategories WHERE serverID = ? AND slug = ?");
        $thisCategory->execute(array($readThisServer["id"], get("category")));
        $readThisCategory = $thisCategory->fetch();
        if ($thisCategory->rowCount() > 0) {
          $categoryID = $readThisCategory["id"];
        }
      }
      else {
        $_GET["category"] = "0";
        $categoryID = get("category");
      }
      $productCategories = $db->prepare("SELECT * FROM ProductCategories WHERE serverID = ? AND parentID = ?");
      $productCategories->execute(array($readThisServer["id"], $categoryID));
    }

    require_once(__ROOT__.'/apps/main/private/packages/class/extraresources/extraresources.php');
    $extraResourcesJS = new ExtraResources('js');
    $extraResourcesJS->addResource('/apps/main/public/assets/js/store.js');
  }
?>
<section class="section store-section">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Ana Sayfa</a></li>
            <?php if (get("server")): ?>
              <?php if ($thisServer->rowCount() > 0): ?>
                <?php if (get("category") == "0"): ?>
                  <li class="breadcrumb-item"><a href="/magaza">Mağaza</a></li>
                  <li class="breadcrumb-item active" aria-current="page"><?php echo $readThisServer["name"]; ?></li>
                <?php else: ?>
                  <li class="breadcrumb-item"><a href="/magaza">Mağaza</a></li>
                  <li class="breadcrumb-item"><a href="/magaza/<?php echo $readThisServer["slug"]; ?>"><?php echo $readThisServer["name"]; ?></a></li>
                  <li class="breadcrumb-item active" aria-current="page"><?php echo $readThisCategory["name"]; ?></li>
                <?php endif; ?>
              <?php else: ?>
                <li class="breadcrumb-item active" aria-current="page">Mağaza</li>
              <?php endif; ?>
            <?php else: ?>
              <li class="breadcrumb-item active" aria-current="page">Mağaza</li>
            <?php endif; ?>
          </ol>
        </nav>
      </div>
    </div>
    <?php if (get("action") == "getAll"): ?>
      <div class="row">
        <?php if ($servers->rowCount() > 0): ?>
          <?php foreach ($servers as $readServers): ?>
            <div class="col-md-3">
              <div class="img-card-wrapper">
                <div class="img-container">
                  <a class="img-card" href="/magaza/<?php echo $readServers["slug"]; ?>">
                    <img class="card-img-top lazyload" data-src="/apps/main/public/assets/img/servers/<?php echo $readServers["imageID"].'.'.$readServers["imageType"]; ?>" src="/apps/main/public/assets/img/loaders/server.png" alt="<?php echo $serverName." Sunucu - ".$readServers["name"]; ?>">
                  </a>
                  <div class="img-card-bottom">
                    <h5 class="mb-0">
                      <a class="text-white" href="/magaza/<?php echo $readServers["slug"]; ?>">
                        <?php echo $readServers["name"]; ?>
                      </a>
                    </h5>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="col-md-12">
            <?php echo alertError("Siteye henüz sunucu verisi eklenmemiş!"); ?>
          </div>
        <?php endif; ?>
      </div>
    <?php elseif (get("action") == "get" && get("server")): ?>
      <div class="row">
        <div id="modalBox"></div>
        <div class="col-md-3">
          <?php if ($servers->rowCount() > 0): ?>
            <div class="card">
              <div class="card-header">
                Sunucular
              </div>
              <div class="card-body p-0">
                <ul class="list-group list-group-flush">
                  <?php foreach ($servers as $readServers): ?>
                    <li class="list-group-item <?php echo ($readServers["slug"] == get("server")) ? "active":null; ?>">
                      <a href="/magaza/<?php echo $readServers["slug"]; ?>">
                        <?php echo $readServers["name"]; ?>
                      </a>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </div>
            </div>
          <?php else: ?>
            <?php echo alertError("Sunucu bulunamadı!"); ?>
          <?php endif; ?>
        </div>
        <div class="col-md-9">
          <?php if (get("server") && $thisServer->rowCount() > 0): ?>
            <?php if ($readSettings["topSalesStatus"] == 1): ?>
              <?php
                $topSales = $db->prepare("SELECT P.*, COUNT(*) AS productCount FROM StoreHistory SH INNER JOIN Products P ON SH.productID = P.id WHERE P.serverID = ? AND P.categoryID = ? GROUP BY P.id ORDER BY productCount DESC LIMIT 4");
                $topSales->execute(array($readThisServer["id"], $categoryID));
              ?>
              <?php if ($topSales->rowCount() > 0): ?>
                <div class="card">
                  <div class="card-header">
                    En Çok Satılan Ürünler
                  </div>
                  <div class="card-body">
                    <div class="row store-cards">
                      <?php foreach ($topSales as $readTopSales): ?>
                        <?php $discountedPriceStatus = ($readTopSales["discountedPrice"] != 0 && ($readTopSales["discountExpiryDate"] > date("Y-m-d H:i:s") || $readTopSales["discountExpiryDate"] == '1000-01-01 00:00:00')); ?>
                        <div class="col-md-3">
                          <div class="store-card">
                            <?php if ($discountedPriceStatus == true): ?>
                              <?php $discountPercent = round((($readTopSales["price"]-$readTopSales["discountedPrice"])*100)/($readTopSales["price"])); ?>
                              <div class="store-card-discount">
                                <span>%<?php echo $discountPercent; ?></span>
                              </div>
                            <?php endif; ?>
                            <img class="store-card-img lazyload" data-src="/apps/main/public/assets/img/store/products/<?php echo $readTopSales["imageID"].'.'.$readTopSales["imageType"]; ?>" src="/apps/main/public/assets/img/loaders/store.png" alt="<?php echo $serverName." Ürün - ".$readTopSales["name"]." Satın Al"; ?>">
                            <div class="row store-card-text">
                              <div class="col">
                                <span><?php echo $readTopSales["name"]; ?></span>
                              </div>
                              <div class="col-auto">
                                <?php if ($discountedPriceStatus == true): ?>
                                  <span class="old-price"><?php echo $readTopSales["price"]; ?><i class="fa fa-try"></i></span>
                                  <small>/</small>
                                  <?php $newPrice = $readTopSales["discountedPrice"]; ?>
                                  <span class="price"><?php echo $newPrice; ?><i class="fa fa-try"></i></span>
                                <?php else: ?>
                                  <span class="price"><?php echo $readTopSales["price"]; ?><i class="fa fa-try"></i></span>
                                <?php endif; ?>
                              </div>
                            </div>
                            <button class="btn btn-success w-100 stretched-link store-card-button openBuyModal" product-id="<?php echo $readTopSales["id"]; ?>">Satın Al</button>
                          </div>
                        </div>
                      <?php endforeach; ?>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
            <?php endif; ?>

            <?php if ($productCategories->rowCount() > 0): ?>
              <div class="card">
                <div class="card-header">
                  Kategoriler
                </div>
                <div class="card-body">
                  <div class="row store-cards">
                    <?php foreach ($productCategories as $readProductCategories): ?>
                      <div class="col-md-3">
                        <div class="store-card">
                          <img class="store-card-img lazyload" data-src="/apps/main/public/assets/img/store/categories/<?php echo $readProductCategories["imageID"].'.'.$readProductCategories["imageType"]; ?>" src="/apps/main/public/assets/img/loaders/store.png" alt="<?php echo $serverName." Kategori - ".$readProductCategories["name"]." Ürünlerini Görüntüle"; ?>">
                          <div class="store-card-text d-flex justify-content-center">
                            <span><?php echo $readProductCategories["name"]; ?></span>
                          </div>
                          <a class="btn btn-primary w-100 stretched-link store-card-button" href="/magaza/<?php echo $readThisServer["slug"]; ?>/<?php echo $readProductCategories["slug"]; ?>">Ürünleri Görüntüle</a>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            <?php endif; ?>

            <?php
              $products = $db->prepare("SELECT * FROM Products WHERE serverID = ? AND categoryID = ?");
              $products->execute(array($readThisServer["id"], $categoryID));
            ?>
            <?php if ($products->rowCount() > 0): ?>
              <div class="card">
                <div class="card-header">
                  Ürünler
                </div>
                <div class="card-body">
                  <div class="row store-cards">
                    <?php foreach ($products as $readProducts): ?>
                      <?php $discountedPriceStatus = ($readProducts["discountedPrice"] != 0 && ($readProducts["discountExpiryDate"] > date("Y-m-d H:i:s") || $readProducts["discountExpiryDate"] == '1000-01-01 00:00:00')); ?>
                      <div class="col-md-3">
                        <div class="store-card">
                          <?php if ($discountedPriceStatus == true): ?>
                            <?php $discountPercent = round((($readProducts["price"]-$readProducts["discountedPrice"])*100)/($readProducts["price"])); ?>
                            <div class="store-card-discount">
                              <span>%<?php echo $discountPercent; ?></span>
                            </div>
                          <?php endif; ?>
                          <img class="store-card-img lazyload" data-src="/apps/main/public/assets/img/store/products/<?php echo $readProducts["imageID"].'.'.$readProducts["imageType"]; ?>" src="/apps/main/public/assets/img/loaders/store.png" alt="<?php echo $serverName." Ürün - ".$readProducts["name"]." Satın Al"; ?>">
                          <div class="row store-card-text">
                            <div class="col">
                              <span><?php echo $readProducts["name"]; ?></span>
                            </div>
                            <div class="col-auto">
                              <?php if ($discountedPriceStatus == true): ?>
                                <span class="old-price"><?php echo $readProducts["price"]; ?><i class="fa fa-try"></i></span>
                                <small>/</small>
                                <?php $newPrice = $readProducts["discountedPrice"]; ?>
                                <span class="price"><?php echo $newPrice; ?><i class="fa fa-try"></i></span>
                              <?php else: ?>
                                <span class="price"><?php echo $readProducts["price"]; ?><i class="fa fa-try"></i></span>
                              <?php endif; ?>
                            </div>
                          </div>
                          <button class="btn btn-success w-100 stretched-link store-card-button openBuyModal" product-id="<?php echo $readProducts["id"]; ?>">Satın Al</button>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            <?php else: ?>
              <?php if ($productCategories->rowCount() == 0): ?>
                <?php echo alertError("Bu sayfaya ait ürün bulunamadı!"); ?>
              <?php endif; ?>
            <?php endif; ?>
          <?php else: ?>
            <?php echo alertError("Bu sayfaya ait veri bulunamadı!"); ?>
          <?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <?php go("/404"); ?>
    <?php endif; ?>
  </div>
</section>
