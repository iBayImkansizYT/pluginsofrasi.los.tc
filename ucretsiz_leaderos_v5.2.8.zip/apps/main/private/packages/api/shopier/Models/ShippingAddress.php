<?php


namespace Shopier\Models;


class ShippingAddress extends Address
{

}