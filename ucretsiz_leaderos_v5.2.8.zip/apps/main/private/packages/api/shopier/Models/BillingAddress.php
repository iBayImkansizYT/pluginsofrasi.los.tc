<?php


namespace Shopier\Models;


class BillingAddress extends Address
{

}