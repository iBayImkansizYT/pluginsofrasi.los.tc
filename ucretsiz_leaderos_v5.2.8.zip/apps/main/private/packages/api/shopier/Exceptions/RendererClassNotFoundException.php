<?php


namespace Shopier\Exceptions;


use Exception;

class RendererClassNotFoundException extends Exception
{

}