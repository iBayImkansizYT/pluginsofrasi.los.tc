<?php


namespace Shopier\Enums;


class WebsiteIndex
{
    const SITE_1 = 1;
    const SITE_2 = 2;
    const SITE_3 = 3;
    const SITE_4 = 4;
    const SITE_5 = 5;
}