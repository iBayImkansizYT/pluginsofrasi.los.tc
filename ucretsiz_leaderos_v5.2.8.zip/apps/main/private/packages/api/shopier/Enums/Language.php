<?php


namespace Shopier\Enums;


class Language
{
    const TR = 0;
    const EN = 1;
}