<?php
  if (isset($_POST["searchAccount"]) && post("search") != null) {
    go('/oyuncu/'.convertURL(post("search")));
  }
?>
<header class="header sticky-top">
  <nav class="navbar navbar-expand-lg navbar-dark shadow-none">
    <div class="container">
      <a class="navbar-brand <?php echo (($readSettings["headerLogoType"] == 2) ? 'image' : null); ?>" href="/">
        <?php if ($readSettings["headerLogoType"] == 1): ?>
          <?php echo $serverName; ?>
        <?php elseif ($readSettings["headerLogoType"] == 2): ?>
          <img src="/apps/main/public/assets/img/extras/logo.png" alt="<?php echo $serverName; ?> Logo">
        <?php else: ?>
          <?php echo $serverName; ?>
        <?php endif; ?>
      </a>
      <button class="navbar-toggler p-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="navbar-collapse collapse justify-content-between align-items-center w-100" id="navbarSupportedContent">
        <ul class="nav navbar-nav mx-auto text-center">
          <?php
            $activatedStatus = false;
            $headerJSON = json_decode($readTheme["header"], true);
          ?>
          <?php foreach ($headerJSON as $readHeader): ?>
            <?php if ($readHeader["pagetype"] == "support"): ?>
              <?php if (isset($_SESSION["login"])): ?>
                <?php
                  $unreadMessages = $db->prepare("SELECT S.id FROM Supports S INNER JOIN SupportCategories SC ON S.categoryID = SC.id INNER JOIN Servers Se ON S.serverID = Se.id WHERE S.statusID = ? AND S.readStatus = ? AND S.accountID = ?");
                  $unreadMessages->execute(array(2, 0, $readAccount["id"]));
                ?>
                <?php if ($unreadMessages->rowCount() > 0): ?>
                  <?php $readHeader["title"].=" <span>(".$unreadMessages->rowCount().")</span>"; ?>
                <?php endif; ?>
              <?php endif; ?>
            <?php endif; ?>
            <?php if (isset($readHeader["children"])): ?>
              <li class="nav-item dropdown <?php echo (((get("route") == $readHeader["pagetype"]) && ($activatedStatus == false)) ? "active" : null); ?>">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="<?php echo $readHeader["icon"]; ?>"></i> <?php echo $readHeader["title"]; ?>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <?php foreach ($readHeader["children"] as $readHeaderChildren): ?>
                    <a class="dropdown-item" href="<?php echo $readHeaderChildren["url"]; ?>" <?php echo (($readHeaderChildren["tabstatus"] == 1) ? "rel=\"external\"" : null); ?>><?php echo $readHeaderChildren["title"]; ?></a>
                  <?php endforeach; ?>
                </div>
              </li>
            <?php else: ?>
              <li class="nav-item <?php echo (((get("route") == $readHeader["pagetype"]) && ($activatedStatus == false)) ? "active" : null); ?>">
                <a class="nav-link" href="<?php echo $readHeader["url"]; ?>" <?php echo (($readHeader["tabstatus"] == 1) ? "rel=\"external\"" : null); ?>><i class="<?php echo $readHeader["icon"]; ?>"></i> <?php echo $readHeader["title"]; ?></a>
              </li>
            <?php endif; ?>
            <?php if (get("route") == $readHeader["pagetype"]): ?>
              <?php $activatedStatus = true; ?>
            <?php endif; ?>
          <?php endforeach; ?>
          <?php if (isset($_SESSION["login"])): ?>
            <li class="nav-item mobil <?php echo ((get("route") == 'profile') ? 'active' : null); ?>">
              <a class="nav-link" href="/profil">
                <i class="fa fa-user-circle"></i>
                <span>Profil</span>
              </a>
            </li>
            <li class="nav-item mobil">
              <a class="nav-link" href="/kredi/yukle">
                <i class="fa fa-money"></i>
                <span>Kredi: <strong><?php echo $readAccount["credit"]; ?></strong></span>
              </a>
            </li>
            <?php if ($readAccount["permission"] == 1 || $readAccount["permission"] == 2 || $readAccount["permission"] == 3 || $readAccount["permission"] == 4 || $readAccount["permission"] == 5): ?>
              <li class="nav-item mobil">
                <a class="nav-link" href="/yonetim-paneli">
                  <i class="fa fa-dashboard"></i>
                  <span>Yönetim Paneli</span>
                </a>
              </li>
            <?php endif; ?>
            <li class="nav-item mobil">
              <a class="nav-link" href="/cikis-yap" onclick="return confirm('Çıkış yapmak istediğinize emin misiniz?');">
                <i class="fa fa-sign-out"></i>
                <span>Çıkış Yap</span>
              </a>
            </li>
          <?php else : ?>
            <li class="nav-item mobil <?php echo ((get("route") == 'login') ? 'active' : null); ?>">
              <a class="nav-link" href="/giris-yap">
                <i class="fa fa-sign-in"></i>
                <span>Giriş Yap</span>
              </a>
            </li>
            <li class="nav-item mobil <?php echo ((get("route") == 'register') ? 'active' : null); ?>">
              <a class="nav-link" href="/kayit-ol">
                <i class="fa fa-user-plus"></i>
                <span>Kayıt Ol</span>
              </a>
            </li>
          <?php endif; ?>
          <li class="nav-item mobil">
            <a class="nav-link" href="#" style="background-color: transparent !important; border-color: transparent !important;">
              <form action="" method="post">
                <div class="input-group mb-2">
                  <input type="text" name="search" placeholder="Oyuncu Ara" class="form-control" aria-label="Oyuncu Ara" aria-describedby="basic-addon2" required="required">
                  <div class="input-group-append">
                    <button type="submit" name="searchAccount" class="theme-color btn btn-primary">Ara</button>
                  </div>
                </div>
              </form>
            </a>
          </li>
        </ul>
        <ul class="nav navbar-nav navbar-right navbar-buttons flex-row justify-content-center flex-nowrap">
          <?php if (isset($_SESSION["login"])): ?>
            <li class="nav-item dropdown pc <?php echo ((get("route") == "profile") ? "active" : null); ?>">
              <a id="profileDropdown" class="nav-link dropdown-toggle <?php echo ((get("route") == "profile") ? "active" : null); ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
                <div class="d-inline-flex align-items-center">
                  <?php echo minecraftHead($readSettings["avatarAPI"], $readAccount["realname"], 14, "mr-1"); ?>
                  <?php echo $readAccount["realname"]; ?>
                </div>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="/profil">
                  <i class="fa fa-user-circle mr-1"></i>
                  <span>Profil</span>
                </a>
                <a class="dropdown-item" href="/kredi/yukle">
                  <i class="fa fa-money mr-1"></i>
                  <span>Kredi: <strong><?php echo $readAccount["credit"]; ?> <i class="fa fa-plus-circle text-success"></i></strong></span>
                </a>
                <?php if ($readAccount["permission"] == 1 || $readAccount["permission"] == 2 || $readAccount["permission"] == 3 || $readAccount["permission"] == 4 || $readAccount["permission"] == 5): ?>
                  <a class="dropdown-item" rel="external" href="/yonetim-paneli">
                    <i class="fa fa-dashboard mr-1"></i>
                    <span>Yönetim Paneli</span>
                  </a>
                <?php endif; ?>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="/cikis-yap" onclick="return confirm('Çıkış yapmak istediğinize emin misiniz?');">
                  <i class="fa fa-sign-out mr-1"></i>
                  <span>Çıkış Yap</span>
                </a>
              </div>
            </li>
          <?php else : ?>
            <li class="nav-item pc">
              <a class="nav-link" href="/giris-yap">Giriş Yap</a>
            </li>
            <li class="nav-item pc active">
              <a class="nav-link" href="/kayit-ol">Kayıt Ol</a>
            </li>
          <?php endif; ?>
          <li class="nav-item nav-search pc">
            <a class="nav-link" href="#">
              <form action="" method="post">
                <div class="searchbar">
                  <input class="search-input" type="text" name="search" placeholder="Oyuncu Ara" autocomplete="off" required="required">
                  <button type="submit" name="searchAccount" class="theme-color btn search-icon">
                    <i class="fa fa-search"></i>
                  </button>
                </div>
              </form>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <nav class="navbar navbar-server" data-toggle="onlinebox">
    <div class="container">
      <div class="navbar-online">
        Çevrimiçi: <span data-toggle="onlinetext" server-ip="<?php echo $serverIP; ?>">-/-</span>
      </div>
      <div class="navbar-ip" data-toggle="copyip" data-clipboard-action="copy" data-clipboard-text="<?php echo $serverIP; ?>">
        <span class="py-2" data-toggle="tooltip" data-placement="bottom" title="Sunucu Adresini Kopyala">
          <?php echo $serverIP; ?>
        </span>
      </div>
      <div class="navbar-version">
        Sürüm: <?php echo $serverVersion; ?>
      </div>
    </div>
  </nav>
</header>

<!-- Preloader -->
<?php if ($readSettings["preloaderStatus"] == 1): ?>
  <div id="preloader">
    <div class="spinner-border" role="status">
      <span class="sr-only">Yükleniyor...</span>
    </div>
  </div>
<?php endif; ?>
